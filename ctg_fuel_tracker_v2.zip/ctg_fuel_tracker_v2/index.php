<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>CTG Fuel Tracker</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css"/>
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
@keyframes grad{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}
html,body{height:100%;overflow:hidden;font-family:'Segoe UI',system-ui,-apple-system,sans-serif;background:#0a0f1e}
#app{position:fixed;top:0;left:0;right:0;bottom:0}
#map{width:100%;height:100%}
#topbar{position:absolute;top:10px;left:50%;transform:translateX(-50%);z-index:900;background:rgba(10,15,30,0.94);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);border:1px solid rgba(255,255,255,0.12);border-radius:50px;padding:8px 16px;display:flex;align-items:center;gap:10px;box-shadow:0 4px 20px rgba(0,0,0,.4);white-space:nowrap;max-width:calc(100vw - 20px)}
#topbar h1{font-size:13px;font-weight:600;color:#fff}
#topbar h1 span{color:#22c55e}
#pump-count{font-size:11px;color:rgba(255,255,255,0.5);background:rgba(255,255,255,0.08);padding:3px 8px;border-radius:20px}
.legend{position:absolute;bottom:105px;left:10px;z-index:900;background:rgba(10,15,30,0.9);backdrop-filter:blur(8px);border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:8px 12px}
.leg{display:flex;align-items:center;gap:6px;font-size:11px;color:rgba(255,255,255,0.75);margin-bottom:4px}
.leg:last-child{margin-bottom:0}
.dot{width:10px;height:10px;border-radius:50%;flex-shrink:0}
/* BOTTOM BAR - always visible */
#fabs{position:absolute;bottom:0;left:0;right:0;z-index:900;display:flex;padding:10px 10px calc(10px + env(safe-area-inset-bottom,0px));background:rgba(8,12,25,0.92);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border-top:1px solid rgba(255,255,255,0.08);gap:8px}
.fab{flex:1;padding:13px 8px;border-radius:12px;border:none;font-size:13px;font-weight:600;cursor:pointer;color:#fff;display:flex;align-items:center;justify-content:center;gap:7px;touch-action:manipulation;-webkit-appearance:none;min-height:48px;background:linear-gradient(-45deg,#065f46,#0f766e,#166534,#064e3b);background-size:300% 300%;animation:grad 4s ease infinite}
.fab:active{opacity:.75}
.fab-admin{background:linear-gradient(-45deg,#1e3a5f,#1e40af,#312e81,#0f172a);background-size:300% 300%;animation:grad 5s ease infinite}
/* Panel */
#panel{position:absolute;z-index:1000;background:linear-gradient(-45deg,#0a0f1e,#0d2137,#0a1f18,#12100e);background-size:400% 400%;animation:grad 10s ease infinite;display:flex;flex-direction:column;transition:transform .28s cubic-bezier(.4,0,.2,1)}
@media(min-width:700px){
  #panel{top:0;right:0;width:340px;height:100%;transform:translateX(100%);border-left:1px solid rgba(255,255,255,0.1)}
  #panel.open{transform:translateX(0)}
  #fabs{position:absolute;bottom:16px;left:auto;right:12px;width:auto;background:transparent;border-top:none;padding:0}
  .fab{flex:none;padding:10px 18px;border-radius:50px;box-shadow:0 4px 16px rgba(0,0,0,.35)}
  .legend{bottom:75px}
}
@media(max-width:699px){
  #panel{bottom:0;left:0;right:0;width:100%;max-height:80vh;transform:translateY(100%);border-radius:18px 18px 0 0;border-top:1px solid rgba(255,255,255,0.1)}
  #panel.open{transform:translateY(0)}
  .legend{display:none}
}
.drag-handle{width:38px;height:4px;background:rgba(255,255,255,0.18);border-radius:2px;margin:8px auto 0;flex-shrink:0}
@media(min-width:700px){.drag-handle{display:none}}
.ph{padding:12px 16px;border-bottom:1px solid rgba(255,255,255,0.08);display:flex;align-items:center;justify-content:space-between;flex-shrink:0;position:sticky;top:0;z-index:2;background:rgba(0,0,0,0.4);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px)}
.ph-title{font-size:14px;font-weight:600;color:#fff;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ph-close{background:rgba(255,255,255,0.1);border:none;border-radius:8px;width:32px;height:32px;cursor:pointer;color:rgba(255,255,255,0.7);font-size:18px;display:flex;align-items:center;justify-content:center;flex-shrink:0;touch-action:manipulation}
.pb{padding:14px 16px;flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;padding-bottom:20px}
.badge{display:inline-flex;align-items:center;gap:5px;padding:4px 11px;border-radius:50px;font-size:12px;font-weight:500;border:1px solid;margin-bottom:3px}
.badge-g{background:rgba(34,197,94,.18);color:#86efac;border-color:rgba(34,197,94,.4)}
.badge-a{background:rgba(245,158,11,.18);color:#fcd34d;border-color:rgba(245,158,11,.4)}
.badge-r{background:rgba(239,68,68,.18);color:#fca5a5;border-color:rgba(239,68,68,.4)}
.badge-k{background:rgba(156,163,175,.12);color:#d1d5db;border-color:rgba(156,163,175,.25)}
.badge-pm{background:rgba(239,68,68,.18);color:#fca5a5;border-color:rgba(239,68,68,.4)}
.badge-mid{background:rgba(245,158,11,.18);color:#fcd34d;border-color:rgba(245,158,11,.4)}
.badge-pn{background:rgba(34,197,94,.18);color:#86efac;border-color:rgba(34,197,94,.4)}
.ir{display:flex;justify-content:space-between;align-items:flex-start;font-size:13px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.06)}
.ir:last-child{border-bottom:none}
.il{color:rgba(255,255,255,0.45);flex-shrink:0;margin-right:10px}
.iv{color:#e2e8f0;font-weight:500;text-align:right}
.ftable{width:100%;border-collapse:collapse;font-size:13px}
.ftable th{color:rgba(255,255,255,0.4);font-weight:500;padding:7px 8px;border-bottom:1px solid rgba(255,255,255,0.08);text-align:left}
.ftable th:not(:first-child){text-align:center}
.ftable td{padding:8px;border-bottom:1px solid rgba(255,255,255,0.05);color:#e2e8f0}
.ftable td:not(:first-child){text-align:center}
.ftable tr:last-child td{border-bottom:none}
.ptag{display:inline-block;font-size:11px;padding:2px 8px;border-radius:4px;font-weight:500}
.ptag-ok{background:rgba(34,197,94,.2);color:#86efac;border:1px solid rgba(34,197,94,.3)}
.ptag-pend{background:rgba(245,158,11,.2);color:#fcd34d;border:1px solid rgba(245,158,11,.3)}
.ptag-na{background:rgba(255,255,255,.07);color:rgba(255,255,255,.4);border:1px solid rgba(255,255,255,.1)}
.stitle{font-size:10px;font-weight:600;color:rgba(255,255,255,.4);text-transform:uppercase;letter-spacing:.08em;margin:14px 0 8px}
.divider{height:1px;background:rgba(255,255,255,0.07);margin:14px 0}
.lbl{font-size:12px;color:rgba(255,255,255,.5);display:block;margin-bottom:5px}
.finput{width:100%;padding:12px 13px;border:1px solid rgba(255,255,255,.18);border-radius:10px;background:rgba(255,255,255,.09);color:#fff;font-size:14px;font-family:inherit;margin-bottom:10px;outline:none;-webkit-appearance:none;appearance:none}
.finput:focus{border-color:rgba(34,197,94,.5)}
.finput::placeholder{color:rgba(255,255,255,.3)}
select.finput option{background:#0d2137;color:#fff}
textarea.finput{resize:vertical;min-height:72px}
.btn{width:100%;padding:13px;border-radius:10px;border:none;font-size:14px;font-weight:600;cursor:pointer;margin-bottom:8px;color:#fff;min-height:48px;display:flex;align-items:center;justify-content:center;touch-action:manipulation;-webkit-appearance:none}
.btn:active{opacity:.8}
.btn-g{background:linear-gradient(-45deg,#064e3b,#065f46,#0f766e,#166534);background-size:300% 300%;animation:grad 4s ease infinite}
.btn-b{background:rgba(255,255,255,.1);animation:none}
.btn-r{background:linear-gradient(-45deg,#7f1d1d,#b91c1c);background-size:200% 200%;animation:grad 4s ease infinite}
.btn-sm{padding:9px 14px;width:auto;font-size:12px;margin-bottom:0;border-radius:8px;min-height:38px}
.fgroup{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-radius:10px;padding:12px;margin-bottom:8px}
.fgroup-title{font-size:13px;font-weight:600;color:#e2e8f0;margin-bottom:10px}
.fgrow{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.fgrow .finput{margin-bottom:0}
.rcard{padding:10px 12px;background:rgba(255,255,255,.06);border-radius:10px;margin-bottom:8px;border:1px solid rgba(255,255,255,.08)}
.rcard p{font-size:13px;color:#e2e8f0;margin-bottom:4px}
.rcard time{font-size:11px;color:rgba(255,255,255,.4)}
.alert-blue{background:rgba(59,130,246,.14);border:1px solid rgba(59,130,246,.3);border-radius:10px;padding:11px 13px;font-size:13px;color:#93c5fd;margin-bottom:12px;line-height:1.6}
.alert-amber{background:rgba(245,158,11,.14);border:1px solid rgba(245,158,11,.3);border-radius:10px;padding:11px 13px;font-size:13px;color:#fcd34d;margin-bottom:12px;line-height:1.6}
.srow{display:flex;align-items:center;gap:6px;margin-bottom:12px;flex-wrap:wrap}
#toast{position:fixed;bottom:85px;left:50%;transform:translateX(-50%);background:rgba(10,15,30,.96);border:1px solid rgba(255,255,255,.15);color:#fff;padding:10px 22px;border-radius:50px;font-size:13px;z-index:3000;opacity:0;pointer-events:none;transition:opacity .3s;max-width:calc(100vw - 32px);text-align:center;white-space:nowrap}
#toast.show{opacity:1}
.leaflet-top,.leaflet-bottom{z-index:800!important}
</style>
</head>
<body>
<div id="app">
  <div id="map"></div>
  <div id="topbar">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2.2" style="flex-shrink:0"><path d="M3 22V9l9-7 9 7v13"/><path d="M14 22v-7H10v7"/><path d="M9 9h6v5H9z"/></svg>
    <h1>CTG <span>Fuel</span> Tracker</h1>
    <span id="pump-count">লোড...</span>
  </div>
  <div class="legend">
    <div class="leg"><div class="dot" style="background:#22c55e"></div>তেল আছে</div>
    <div class="leg"><div class="dot" style="background:#f59e0b"></div>সীমিত</div>
    <div class="leg"><div class="dot" style="background:#ef4444"></div>নেই</div>
    <div class="leg"><div class="dot" style="background:#9ca3af"></div>অজানা</div>
  </div>
  <div id="fabs">
    <button class="fab" onclick="userAddPump()">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
      পাম্প যোগ করুন
    </button>
    <button class="fab fab-admin" onclick="window.location='/admin/'">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M6 20v-2a6 6 0 0 1 12 0v2"/></svg>
      Admin
    </button>
  </div>
  <div id="toast"></div>
  <div id="panel">
    <div class="drag-handle"></div>
    <div class="ph">
      <div class="ph-title" id="ptitle">বিস্তারিত</div>
      <button class="ph-close" onclick="closePanel()">✕</button>
    </div>
    <div class="pb" id="pbody"></div>
  </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<script>
const SC={available:{l:"তেল আছে",c:"#22c55e",b:"badge-g"},limited:{l:"সীমিত",c:"#f59e0b",b:"badge-a"},unavailable:{l:"নেই",c:"#ef4444",b:"badge-r"},unknown:{l:"অজানা",c:"#9ca3af",b:"badge-k"}};
const SER={many:{l:"সিরিয়াল বেশি",b:"badge-pm",c:"#ef4444"},mid:{l:"সিরিয়াল মাঝারি",b:"badge-mid",c:"#f59e0b"},none:{l:"সিরিয়াল নেই",b:"badge-pn",c:"#22c55e"},unknown:{l:"অজানা",b:"badge-k",c:"#9ca3af"}};
const FT=["অকটেন","পেট্রোল","ডিজেল"];
let map,markers={},selId=null,toastTimer;
function isMob(){return window.innerWidth<700;}
function mkIcon(s){const c=SC[s]?.c||"#9ca3af";return L.divIcon({className:"",html:`<div style="width:18px;height:18px;background:${c};border-radius:50%;border:2.5px solid white;box-shadow:0 2px 8px rgba(0,0,0,.5)"></div>`,iconSize:[18,18],iconAnchor:[9,9]});}
function fuelColor(av){return av==="আছে"?"#22c55e":av==="সীমিত"?"#f59e0b":av==="নেই"?"#ef4444":"#9ca3af";}
async function loadStations(){
  try{const r=await fetch('/api/stations.php');const d=await r.json();if(!d.success)return;
  Object.values(markers).forEach(m=>map.removeLayer(m));markers={};
  d.stations.forEach(s=>{const m=L.marker([s.lat,s.lng],{icon:mkIcon(s.status)}).addTo(map).on("click",()=>openStation(s.id));markers[s.id]=m;});
  document.getElementById("pump-count").textContent=`${d.stations.length}টি পাম্প`;}catch(e){}
}
async function openStation(id){
  selId=id;
  document.getElementById("ptitle").textContent="লোড হচ্ছে...";
  document.getElementById("pbody").innerHTML=`<p style="text-align:center;padding:40px 0;font-size:22px;color:rgba(255,255,255,.4)">⏳</p>`;
  document.getElementById("panel").classList.add("open");
  const r=await fetch(`/api/stations.php?id=${id}`);const d=await r.json();
  if(!d.success){toast("লোড ব্যর্থ।");return;}
  const s=d.station,cfg=SC[s.status]||SC.unknown,ser=SER[s.serial_status||"unknown"]||SER.unknown;
  const fuelsHtml=s.fuels.map(f=>{const av=f.availability||"—";const pr=f.price?`<span class="ptag ptag-ok">৳${parseFloat(f.price).toFixed(0)}/লি.</span>`:`<span class="ptag ptag-na">—</span>`;const pend=f.pending_price?` <span class="ptag ptag-pend">৳${f.pending_price} ⏳</span>`:"";return`<tr><td>${f.fuel_type}</td><td><span style="color:${fuelColor(av)};font-weight:600">${av}</span></td><td>${pr}${pend}</td></tr>`;}).join("");
  const repsHtml=s.reports.length?s.reports.map(r=>{const rc=SC[r.status]||SC.unknown;return`<div class="rcard"><p>${r.note||"কোনো মন্তব্য নেই"} <span style="float:right;color:${rc.c};font-weight:600">${rc.l}</span></p><time>${r.created_at}</time></div>`;}).join(""):`<p style="font-size:13px;color:rgba(255,255,255,.35);text-align:center;padding:14px 0">রিপোর্ট নেই।</p>`;
  document.getElementById("ptitle").innerHTML=s.name+(s.is_user_submitted?`<span style="font-size:10px;background:rgba(59,130,246,.2);color:#93c5fd;padding:2px 7px;border-radius:4px;margin-left:6px;border:1px solid rgba(59,130,246,.3)">user</span>`:"");
  const suggestRows=FT.map(f=>{const key='ps_'+f.replace(/[^\w]/g,'_');const existing=s.pending_suggests&&s.pending_suggests.includes(f);return`<div class="fgroup" style="margin-bottom:8px"><div class="fgroup-title">${f}${existing?` <span style="font-size:10px;color:#fcd34d">⏳ বাকি</span>`:""}</div>${existing?`<p style="font-size:12px;color:rgba(255,255,255,.35)">সাজেশন জমা আছে।</p>`:`<div style="display:grid;grid-template-columns:1fr auto;gap:8px;align-items:end"><div><span class="lbl">নতুন দাম (৳/লি.)</span><input type="number" class="finput" id="${key}" placeholder="132" min="0" step="0.5" inputmode="decimal" style="margin-bottom:0"/></div><button class="btn btn-g btn-sm" onclick="submitPriceSuggest(${id},'${f}','${key}')">জমা</button></div>`}</div>`;}).join("");
  document.getElementById("pbody").innerHTML=`
    <div class="srow"><span class="badge ${cfg.b}"><span style="width:7px;height:7px;border-radius:50%;background:${cfg.c};display:inline-block"></span>${cfg.l}</span><span class="badge ${ser.b}"><span style="width:7px;height:7px;border-radius:50%;background:${ser.c};display:inline-block"></span>${ser.l}</span></div>
    <div class="ir"><span class="il">ঠিকানা</span><span class="iv">${s.address||"—"}</span></div>
    <div class="ir"><span class="il">শেষ আপডেট</span><span class="iv">${s.last_updated}</span></div>
    <div class="stitle">জ্বালানির অবস্থা ও দাম</div>
    <table class="ftable"><thead><tr><th>জ্বালানি</th><th>অবস্থা</th><th>দাম</th></tr></thead><tbody>${fuelsHtml}</tbody></table>
    <div class="divider"></div>
    <div class="stitle">দামের সাজেশন দিন</div>
    <div class="alert-amber">সাজেশন Admin অনুমোদনের পর দেখা যাবে।</div>
    ${suggestRows}
    <div class="divider"></div>
    <div class="stitle">রিপোর্ট করুন</div>
    <span class="lbl">তেলের অবস্থা</span>
    <select id="r-st" class="finput">${Object.entries(SC).map(([k,v])=>`<option value="${k}">${v.l}</option>`).join("")}</select>
    <span class="lbl">সিরিয়াল অবস্থা</span>
    <select id="r-ser" class="finput"><option value="none">সিরিয়াল নেই</option><option value="mid">সিরিয়াল মাঝারি</option><option value="many">সিরিয়াল বেশি</option><option value="unknown">অজানা</option></select>
    <span class="lbl">মন্তব্য (ঐচ্ছিক)</span>
    <textarea id="r-note" class="finput" placeholder="আপনার অভিজ্ঞতা লিখুন..."></textarea>
    <button class="btn btn-g" onclick="submitReport(${id})">রিপোর্ট জমা দিন</button>
    <div class="stitle">সাম্প্রতিক রিপোর্ট</div>${repsHtml}`;
}
async function submitPriceSuggest(sid,fuel,key){
  const inp=document.getElementById(key);if(!inp||!inp.value.trim()){toast("সঠিক দাম লিখুন!");return;}
  const r=await fetch('/api/suggest_price.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({station_id:sid,fuel_type:fuel,price:inp.value.trim()})});
  const d=await r.json();if(d.success){toast(`${fuel} সাজেশন জমা হয়েছে!`);openStation(sid);}else toast(d.error||"সমস্যা।");
}
async function submitReport(sid){
  const b={station_id:sid,status:document.getElementById("r-st").value,serial_status:document.getElementById("r-ser").value,note:document.getElementById("r-note").value.trim()};
  const r=await fetch('/api/report.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
  const d=await r.json();if(d.success){toast("রিপোর্ট জমা হয়েছে!");loadStations();openStation(sid);}else toast(d.error||"সমস্যা।");
}
function userAddPump(){
  document.getElementById("ptitle").textContent="পাম্প যোগ করুন";
  document.getElementById("pbody").innerHTML=`<p style="text-align:center;font-size:24px;padding:30px 0">📍</p><p style="text-align:center;font-size:13px;color:rgba(255,255,255,.4);margin-bottom:10px">Location অ্যাক্সেস করা হচ্ছে...</p>`;
  document.getElementById("panel").classList.add("open");
  if(!navigator.geolocation){showAddForm(null,null,true);return;}
  navigator.geolocation.getCurrentPosition(pos=>{map.flyTo([pos.coords.latitude,pos.coords.longitude],16,{duration:1.2});showAddForm(pos.coords.latitude,pos.coords.longitude,false);},()=>showAddForm(null,null,true),{timeout:8000,enableHighAccuracy:true});
}
function showAddForm(lat,lng,manual){
  document.getElementById("ptitle").textContent="নতুন পাম্প যোগ করুন";
  document.getElementById("pbody").innerHTML=`
    ${lat?`<div class="alert-blue">📍 বর্তমান অবস্থান ব্যবহার করা হচ্ছে।<br><small>${lat.toFixed(5)}, ${lng.toFixed(5)}</small></div>`:
    `<div class="alert-blue">Location পাওয়া যায়নি।</div><span class="lbl">Latitude</span><input type="number" class="finput" id="u-lat" placeholder="22.3569" step="0.00001" inputmode="decimal"/><span class="lbl">Longitude</span><input type="number" class="finput" id="u-lng" placeholder="91.7832" step="0.00001" inputmode="decimal"/>`}
    <span class="lbl">পাম্পের নাম *</span><input type="text" class="finput" id="u-name" placeholder="রহিম ফিলিং স্টেশন"/>
    <span class="lbl">ঠিকানা</span><input type="text" class="finput" id="u-addr" placeholder="কদমতলী, চট্টগ্রাম"/>
    <span class="lbl">সার্বিক অবস্থা</span><select id="u-status" class="finput">${Object.entries(SC).map(([k,v])=>`<option value="${k}">${v.l}</option>`).join("")}</select>
    <span class="lbl">সিরিয়াল</span><select id="u-ser" class="finput"><option value="none">সিরিয়াল নেই</option><option value="mid">মাঝারি</option><option value="many">বেশি</option><option value="unknown">অজানা</option></select>
    <div class="stitle">জ্বালানির অবস্থা ও দাম</div>
    ${FT.map(f=>{const k=f.replace(/[^\w]/g,'_');return`<div class="fgroup"><div class="fgroup-title">${f}</div><div class="fgrow"><div><span class="lbl">অবস্থা</span><select id="us_${k}" class="finput"><option value="আছে">আছে</option><option value="সীমিত">সীমিত</option><option value="নেই">নেই</option><option value="প্রযোজ্য নয়">N/A</option></select></div><div><span class="lbl">দাম (৳)</span><input type="number" class="finput" id="up_${k}" placeholder="130" inputmode="decimal"/></div></div></div>`;}).join("")}
    <button class="btn btn-g" onclick="submitUserStation(${lat||'null'},${lng||'null'})">পাম্প যোগ করুন</button>
    <button class="btn btn-b" onclick="closePanel()">বাতিল</button>`;
}
async function submitUserStation(lat,lng){
  const name=document.getElementById("u-name").value.trim();if(!name){toast("নাম দিন!");return;}
  let la=lat,ln=lng;if(!la){la=parseFloat(document.getElementById("u-lat").value);ln=parseFloat(document.getElementById("u-lng").value);if(isNaN(la)||isNaN(ln)){toast("অবস্থান দিন!");return;}}
  const fuels=FT.map(f=>{const k=f.replace(/[^\w]/g,'_');return{fuel_type:f,availability:document.getElementById(`us_${k}`).value,price:document.getElementById(`up_${k}`).value||null};});
  const r=await fetch('/api/add_station.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,address:document.getElementById("u-addr").value.trim(),lat:la,lng:ln,status:document.getElementById("u-status").value,serial_status:document.getElementById("u-ser").value,fuels,is_user_submitted:1})});
  const d=await r.json();if(d.success){toast(`"${name}" যোগ হয়েছে!`);closePanel();loadStations();}else toast(d.error||"সমস্যা।");
}
function closePanel(){document.getElementById("panel").classList.remove("open");selId=null;}
function toast(msg){clearTimeout(toastTimer);const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");toastTimer=setTimeout(()=>t.classList.remove("show"),3500);}
const panel=document.getElementById("panel");
let startY=0;
panel.addEventListener('touchstart',e=>{startY=e.touches[0].clientY;},{passive:true});
panel.addEventListener('touchend',e=>{if(e.changedTouches[0].clientY-startY>80&&isMob())closePanel();},{passive:true});
window.addEventListener('resize',()=>map&&map.invalidateSize());
async function init(){
  map=L.map("map",{zoomControl:true}).setView([22.3569,91.7832],13);
  L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png",{attribution:'© <a href="https://openstreetmap.org">OSM</a> © <a href="https://carto.com">CARTO</a>',subdomains:"abcd",maxZoom:19}).addTo(map);
  await loadStations();
}
init();
</script>
</body>
</html>
