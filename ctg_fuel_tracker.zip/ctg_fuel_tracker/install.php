<?php
/**
 * CTG Fuel Tracker - Database Installer
 * Run this file ONCE to set up the database.
 * DELETE this file after installation!
 */
require_once '../config.php';

$pdo = getDB();

$sql = "
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100),
  `role` ENUM('superadmin','admin') DEFAULT 'admin',
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `last_login` TIMESTAMP NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `stations` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `address` VARCHAR(255),
  `lat` DECIMAL(10,7) NOT NULL,
  `lng` DECIMAL(10,7) NOT NULL,
  `status` ENUM('available','limited','unavailable','unknown') DEFAULT 'unknown',
  `serial_status` ENUM('none','mid','many','unknown') DEFAULT 'unknown',
  `is_user_submitted` TINYINT(1) DEFAULT 0,
  `is_active` TINYINT(1) DEFAULT 1,
  `last_updated` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `fuel_data` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `station_id` INT NOT NULL,
  `fuel_type` ENUM('অকটেন','পেট্রোল','ডিজেল') NOT NULL,
  `availability` ENUM('আছে','সীমিত','নেই','প্রযোজ্য নয়') DEFAULT 'আছে',
  `price` DECIMAL(8,2) NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`station_id`) REFERENCES `stations`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `station_fuel` (`station_id`, `fuel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `reports` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `station_id` INT NOT NULL,
  `status` ENUM('available','limited','unavailable','unknown') NOT NULL,
  `serial_status` ENUM('none','mid','many','unknown') DEFAULT 'unknown',
  `note` TEXT,
  `reporter_ip` VARCHAR(45),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`station_id`) REFERENCES `stations`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `price_suggestions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `station_id` INT NOT NULL,
  `fuel_type` ENUM('অকটেন','পেট্রোল','ডিজেল') NOT NULL,
  `suggested_price` DECIMAL(8,2) NOT NULL,
  `status` ENUM('pending','approved','rejected') DEFAULT 'pending',
  `reporter_ip` VARCHAR(45),
  `reviewed_by` INT NULL,
  `reviewed_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`station_id`) REFERENCES `stations`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

try {
    $pdo->exec($sql);
    echo '<div style="font-family:sans-serif;max-width:600px;margin:40px auto;padding:20px;background:#f0fdf4;border:1px solid #86efac;border-radius:8px;">';
    echo '<h2 style="color:#15803d">✅ Tables created successfully!</h2>';

    // Insert default superadmin
    $stmt = $pdo->prepare("SELECT id FROM admin_users WHERE username = 'admin'");
    $stmt->execute();
    if (!$stmt->fetch()) {
        $stmt = $pdo->prepare("INSERT INTO admin_users (username, password, full_name, email, role) VALUES (?, ?, ?, ?, 'superadmin')");
        $stmt->execute(['admin', password_hash('Admin@CTG2025', PASSWORD_DEFAULT), 'Super Admin', 'admin@ctgfuel.com']);
        echo '<p>✅ Default admin created: <strong>username: admin | password: Admin@CTG2025</strong></p>';
    }

    // Insert sample Chattogram stations
    $stations = [
        ['মেঘনা পেট্রোলিয়াম', 'আগ্রাবাদ বাণিজ্যিক এলাকা, চট্টগ্রাম', 22.3248, 91.8163, 'available', 'none'],
        ['পদ্মা ফিলিং স্টেশন', 'নাসিরাবাদ, চট্টগ্রাম', 22.3510, 91.7912, 'limited', 'many'],
        ['জামালখান ফিলিং স্টেশন', 'জামালখান রোড, চট্টগ্রাম', 22.3680, 91.8190, 'available', 'mid'],
        ['হালিশহর ফিলিং স্টেশন', 'হালিশহর, চট্টগ্রাম', 22.3098, 91.8210, 'unavailable', 'none'],
        ['পাহাড়তলী ফিলিং স্টেশন', 'পাহাড়তলী, চট্টগ্রাম', 22.4012, 91.7720, 'available', 'none'],
        ['মুরাদপুর ফিলিং স্টেশন', 'মুরাদপুর, চট্টগ্রাম', 22.3605, 91.8002, 'limited', 'mid'],
        ['অক্সিজেন ফিলিং স্টেশন', 'অক্সিজেন মোড়, চট্টগ্রাম', 22.3902, 91.7818, 'available', 'none'],
        ['ষোলশহর ফিলিং স্টেশন', 'ষোলশহর, চট্টগ্রাম', 22.3450, 91.8040, 'available', 'many'],
        ['বন্দর ফিলিং স্টেশন', 'বন্দর এলাকা, চট্টগ্রাম', 22.3312, 91.8330, 'available', 'none'],
        ['GEC ফিলিং স্টেশন', 'GEC সার্কেল, চট্টগ্রাম', 22.3679, 91.8090, 'limited', 'mid'],
    ];
    $fuels = [
        ['অকটেন', 'আছে', 130],
        ['পেট্রোল', 'আছে', 125],
        ['ডিজেল', 'আছে', 109],
    ];

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM stations");
    $stmt->execute();
    if ($stmt->fetchColumn() == 0) {
        foreach ($stations as $s) {
            $st = $pdo->prepare("INSERT INTO stations (name, address, lat, lng, status, serial_status) VALUES (?,?,?,?,?,?)");
            $st->execute($s);
            $sid = $pdo->lastInsertId();
            foreach ($fuels as $f) {
                $av = ($s[4] === 'unavailable') ? 'নেই' : ($s[4] === 'limited' && $f[0] !== 'পেট্রোল' ? 'সীমিত' : 'আছে');
                $ft = $pdo->prepare("INSERT INTO fuel_data (station_id, fuel_type, availability, price) VALUES (?,?,?,?)");
                $ft->execute([$sid, $f[0], $av, $f[2]]);
            }
        }
        echo '<p>✅ Sample stations inserted successfully.</p>';
    } else {
        echo '<p>ℹ️ Stations already exist, skipped.</p>';
    }

    echo '<p style="color:#dc2626;font-weight:bold">🔴 IMPORTANT: Delete this install.php file immediately after setup!</p>';
    echo '<a href="/" style="background:#15803d;color:white;padding:10px 20px;border-radius:6px;text-decoration:none;display:inline-block;margin-top:10px">→ Go to App</a>';
    echo '</div>';
} catch (Exception $e) {
    echo '<div style="font-family:sans-serif;max-width:600px;margin:40px auto;padding:20px;background:#fef2f2;border:1px solid #fca5a5;border-radius:8px;">';
    echo '<h2 style="color:#dc2626">❌ Error</h2>';
    echo '<p>' . $e->getMessage() . '</p>';
    echo '</div>';
}
