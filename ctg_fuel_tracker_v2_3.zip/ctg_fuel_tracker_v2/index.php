<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>CTG Fuel Tracker</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css"/>
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
:root{
  --or1:#f97316;--or2:#ea580c;--or3:#fb923c;
  --gr1:#22c55e;--gr2:#16a34a;--bl1:#3b82f6;--bl2:#2563eb;--rd1:#ef4444;--am1:#f59e0b;--gy:#6b7280;
  --bg:#f8fafc;--bg2:#ffffff;--bg3:#f1f5f9;--txt:#0f172a;--txt2:#475569;--txt3:#94a3b8;
  --bd:#e2e8f0;--bd2:#cbd5e1;
  --sh:0 1px 3px rgba(0,0,0,.08),0 1px 2px rgba(0,0,0,.06);
  --shm:0 4px 16px rgba(0,0,0,.1),0 2px 6px rgba(0,0,0,.08);
  --shl:0 10px 40px rgba(0,0,0,.14),0 4px 12px rgba(0,0,0,.1);
}
@keyframes ga{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}
@keyframes pulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.5;transform:scale(.8)}}
@keyframes slideUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
@keyframes ping{0%{transform:scale(1);opacity:.7}100%{transform:scale(2.4);opacity:0}}
@keyframes bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}}
html,body{height:100%;overflow:hidden;font-family:'Segoe UI',system-ui,sans-serif;background:var(--bg);color:var(--txt)}
#app{position:fixed;inset:0;display:flex;flex-direction:column}
#hdr{background:var(--bg2);border-bottom:1px solid var(--bd);flex-shrink:0;z-index:1000;box-shadow:var(--sh)}
#hdr-top{display:flex;align-items:center;justify-content:space-between;padding:10px 14px}
.logo{display:flex;align-items:center;gap:10px}
.logo-ic{width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0;background:linear-gradient(-45deg,var(--or1),var(--or2),var(--or3),var(--or1));background-size:300% 300%;animation:ga 4s ease infinite}
.logo-tx h1{font-size:16px;font-weight:800;color:var(--txt);line-height:1.1}
.logo-tx h1 span{background:linear-gradient(135deg,var(--or1),var(--or2));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.logo-tx p{font-size:9px;color:var(--txt3)}
.hdr-r{display:flex;align-items:center;gap:7px}
.live-b{display:flex;align-items:center;gap:5px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:20px;padding:5px 11px;font-size:12px;color:var(--gr2);font-weight:600}
.live-d{width:7px;height:7px;background:var(--gr1);border-radius:50%;animation:pulse 2s infinite}
.rep-btn{display:flex;align-items:center;gap:5px;border:none;border-radius:20px;padding:8px 13px;font-size:12px;font-weight:700;color:#fff;cursor:pointer;white-space:nowrap;touch-action:manipulation;background:linear-gradient(-45deg,var(--or1),var(--or2),var(--or3),var(--or1));background-size:300% 300%;animation:ga 4s ease infinite;box-shadow:0 2px 10px rgba(249,115,22,.4)}
.rep-btn:active{opacity:.82;transform:scale(.96)}
#stats{display:grid;grid-template-columns:repeat(4,1fr);border-top:1px solid var(--bd)}
.si{padding:7px 10px;display:flex;align-items:center;gap:7px;border-right:1px solid var(--bd)}
.si:last-child{border-right:none}
.si-v{font-size:14px;font-weight:700;color:var(--txt);line-height:1}
.si-l{font-size:9px;color:var(--txt3);margin-top:2px}
#mapw{flex:1;position:relative;min-height:0}
#map{width:100%;height:100%}
.map-leg{position:absolute;top:10px;right:10px;z-index:900;background:rgba(255,255,255,.95);backdrop-filter:blur(8px);border:1px solid var(--bd);border-radius:12px;padding:10px 13px;box-shadow:var(--shm)}
.ml{display:flex;align-items:center;gap:7px;font-size:11px;color:var(--txt2);margin-bottom:5px;font-weight:500}
.ml:last-child{margin-bottom:0}
.mld{width:10px;height:10px;border-radius:50%;flex-shrink:0}
.add-fab{position:absolute;bottom:70px;right:14px;z-index:900;width:48px;height:48px;border-radius:50%;border:none;display:flex;align-items:center;justify-content:center;cursor:pointer;color:#fff;box-shadow:var(--shl);background:linear-gradient(-45deg,var(--bl1),var(--bl2),#60a5fa,var(--bl1));background-size:300% 300%;animation:ga 5s ease infinite;touch-action:manipulation}
.add-fab:active{transform:scale(.88)}
#bs{background:var(--bg2);border-top:1px solid var(--bd);flex-shrink:0;display:flex;flex-direction:column;transition:height .32s cubic-bezier(.4,0,.2,1);overflow:hidden;box-shadow:0 -3px 16px rgba(0,0,0,.06)}
#bs.col{height:58px}#bs.exp{height:54vh}
@media(min-width:700px){#bs.exp{height:42vh}}
.bs-hr{padding:0 14px;height:58px;display:flex;align-items:center;justify-content:space-between;cursor:pointer;flex-shrink:0}
.bs-tt{display:flex;align-items:center;gap:7px}
.bs-rd{width:7px;height:7px;background:var(--rd1);border-radius:50%;animation:pulse 1.5s infinite}
.bs-h3{font-size:13px;font-weight:700;color:var(--txt)}
.bs-sb{font-size:9px;color:var(--txt3);margin-top:1px}
.bs-ar{color:var(--txt3);font-size:18px;transition:transform .3s}
#bs.exp .bs-ar{transform:rotate(180deg)}
.bs-ct{padding:0 12px 10px;flex-shrink:0}
.sw{position:relative;margin-bottom:8px}
.sri{width:100%;background:var(--bg3);border:1.5px solid var(--bd);border-radius:10px;padding:9px 12px 9px 34px;color:var(--txt);font-size:13px;outline:none;-webkit-appearance:none;transition:border-color .2s}
.sri:focus{border-color:#93c5fd;background:#fff}
.sri::placeholder{color:var(--txt3)}
.sic{position:absolute;left:11px;top:50%;transform:translateY(-50%);color:var(--txt3);font-size:13px}
.fts{display:flex;gap:6px;overflow-x:auto;padding-bottom:2px;scrollbar-width:none}
.fts::-webkit-scrollbar{display:none}
.ft{padding:6px 13px;border-radius:20px;border:1.5px solid var(--bd);background:var(--bg3);color:var(--txt2);font-size:12px;font-weight:600;white-space:nowrap;cursor:pointer;flex-shrink:0;touch-action:manipulation;transition:all .2s}
.ft.on{background:linear-gradient(-45deg,var(--or1),var(--or2),var(--or3),var(--or1));background-size:300% 300%;animation:ga 4s ease infinite;border-color:transparent;color:#fff;box-shadow:0 2px 8px rgba(249,115,22,.3)}
.ft:active{opacity:.8}
#feed{overflow-y:auto;-webkit-overflow-scrolling:touch;flex:1}
.rc{padding:12px 14px;border-bottom:1px solid var(--bd);display:flex;gap:11px;align-items:flex-start;animation:slideUp .22s ease;background:var(--bg2)}
.rc:active{background:var(--bg3)}
.rc-ic{width:44px;height:44px;border-radius:12px;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:22px;background:linear-gradient(135deg,#fff7ed,#ffedd5);border:1.5px solid #fed7aa}
.rc-bd{flex:1;min-width:0}
.rc-nm{font-size:13px;font-weight:700;color:var(--txt);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rc-mt{font-size:10px;color:var(--txt3);margin-top:2px}
.rc-mt span{color:var(--or1);font-weight:500}
.rc-nt{font-size:11px;color:var(--txt2);margin-top:4px;line-height:1.4;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.rc-ac{display:flex;gap:5px;margin-top:7px;flex-wrap:wrap}
.rb{display:inline-flex;align-items:center;gap:3px;padding:4px 9px;border-radius:16px;border:1px solid var(--bd);background:var(--bg3);color:var(--txt2);font-size:11px;cursor:pointer;white-space:nowrap;font-weight:500;touch-action:manipulation}
.rb:active{opacity:.7}
.rb.mp{border-color:#bfdbfe;color:var(--bl2);background:#eff6ff;font-weight:600}
.rc-rt{display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex-shrink:0}
.ch{padding:3px 9px;border-radius:7px;font-size:10px;font-weight:700;white-space:nowrap}
.cg{background:#f0fdf4;color:#15803d;border:1px solid #bbf7d0}
.ca{background:#fffbeb;color:#b45309;border:1px solid #fde68a}
.cr{background:#fef2f2;color:#dc2626;border:1px solid #fecaca}
.ck{background:var(--bg3);color:var(--gy);border:1px solid var(--bd)}
.pb{font-size:15px;font-weight:800;color:var(--txt)}
.pl{font-size:9px;color:var(--txt3)}
.emp{text-align:center;padding:40px;color:var(--txt3);font-size:13px}
/* Detail */
#dp{position:fixed;inset:0;z-index:2000;background:var(--bg);transform:translateY(100%);transition:transform .3s cubic-bezier(.4,0,.2,1);display:flex;flex-direction:column}
#dp.open{transform:translateY(0)}
.dp-hd{padding:12px 14px;border-bottom:1px solid var(--bd);display:flex;align-items:center;gap:10px;flex-shrink:0;background:var(--bg2);box-shadow:var(--sh)}
.dp-bk{background:var(--bg3);border:1.5px solid var(--bd);border-radius:9px;width:34px;height:34px;display:flex;align-items:center;justify-content:center;cursor:pointer;color:var(--txt2);font-size:18px;flex-shrink:0}
.dp-tt{font-size:14px;font-weight:700;color:var(--txt);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dp-rb{border:none;border-radius:18px;padding:8px 14px;font-size:12px;font-weight:700;color:#fff;cursor:pointer;flex-shrink:0;background:linear-gradient(-45deg,var(--or1),var(--or2),var(--or3),var(--or1));background-size:300% 300%;animation:ga 4s ease infinite;box-shadow:0 2px 8px rgba(249,115,22,.3)}
.dp-body{overflow-y:auto;-webkit-overflow-scrolling:touch;flex:1;padding:16px;background:var(--bg)}
.dp-stl{font-size:10px;font-weight:700;color:var(--txt3);text-transform:uppercase;letter-spacing:.08em;margin:16px 0 9px}
.dp-rw{display:flex;justify-content:space-between;align-items:flex-start;font-size:13px;padding:8px 0;border-bottom:1px solid var(--bd)}
.dp-rw:last-child{border-bottom:none}
.dp-l{color:var(--txt3);font-weight:500}
.dp-v{color:var(--txt);font-weight:600;text-align:right;max-width:65%}
.fg{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px}
.fc{background:var(--bg2);border:1.5px solid var(--bd);border-radius:12px;padding:12px 8px;text-align:center;box-shadow:var(--sh)}
.fc-n{font-size:10px;color:var(--txt3);margin-bottom:6px;font-weight:600}
.fc-s{font-size:12px;font-weight:700;margin-bottom:5px}
.fc-p{font-size:14px;font-weight:800;color:var(--or1)}
.sgr{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:end;margin-bottom:8px}
.dp-in{width:100%;background:var(--bg2);border:1.5px solid var(--bd);border-radius:9px;padding:10px 12px;color:var(--txt);font-size:13px;outline:none;-webkit-appearance:none;font-family:inherit;transition:border-color .2s}
.dp-in:focus{border-color:#93c5fd}
.dp-in::placeholder{color:var(--txt3)}
.dp-btn{padding:10px 14px;border-radius:9px;border:none;font-size:12px;font-weight:700;cursor:pointer;color:#fff;touch-action:manipulation;min-height:40px;display:flex;align-items:center;justify-content:center}
.dp-or{background:linear-gradient(-45deg,var(--or1),var(--or2),var(--or3),var(--or1));background-size:300% 300%;animation:ga 4s ease infinite;box-shadow:0 2px 8px rgba(249,115,22,.28)}
.dp-btn:active{opacity:.8;transform:scale(.96)}
.rmin{background:var(--bg2);border-radius:10px;padding:10px 12px;margin-bottom:8px;border:1px solid var(--bd);box-shadow:var(--sh)}
.rmin p{font-size:12px;color:var(--txt);margin-bottom:4px}
.rmin time{font-size:10px;color:var(--txt3)}
.ptag{font-size:10px;background:#fffbeb;color:#b45309;border:1px solid #fde68a;padding:2px 7px;border-radius:5px;font-weight:600}
.ambox{background:#fffbeb;border:1px solid #fde68a;border-radius:9px;padding:9px 12px;font-size:12px;color:#92400e;margin-bottom:10px}
/* Modal base */
.modal-bg{position:fixed;inset:0;z-index:3000;background:rgba(0,0,0,.35);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);display:flex;align-items:flex-end;opacity:0;pointer-events:none;transition:opacity .25s}
.modal-bg.open{opacity:1;pointer-events:all}
.modal-sh{background:var(--bg2);border-radius:22px 22px 0 0;border-top:2px solid var(--bd);width:100%;padding:18px 14px calc(18px + env(safe-area-inset-bottom,0px));transform:translateY(40px);transition:transform .3s cubic-bezier(.34,1.2,.64,1);max-height:90vh;overflow-y:auto}
.modal-bg.open .modal-sh{transform:translateY(0)}
.m-hndle{width:40px;height:4px;background:var(--bd2);border-radius:2px;margin:0 auto 16px}
.m-hd{font-size:16px;font-weight:800;color:var(--txt);margin-bottom:14px;display:flex;align-items:center;justify-content:space-between}
.m-cl{background:var(--bg3);border:1.5px solid var(--bd);border-radius:8px;width:30px;height:30px;color:var(--txt2);font-size:15px;cursor:pointer;display:flex;align-items:center;justify-content:center}
.m-lbl{font-size:11px;color:var(--txt2);display:block;margin-bottom:5px;font-weight:600}
.m-inp{width:100%;background:var(--bg3);border:1.5px solid var(--bd);border-radius:9px;padding:10px 12px;color:var(--txt);font-size:13px;outline:none;margin-bottom:10px;-webkit-appearance:none;font-family:inherit;transition:border-color .2s}
.m-inp:focus{border-color:#93c5fd;background:#fff}
.m-inp::placeholder{color:var(--txt3)}
select.m-inp option{background:#fff}
.og{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-bottom:12px}
.oo{padding:10px 8px;border-radius:10px;border:1.5px solid var(--bd);background:var(--bg3);color:var(--txt2);font-size:12px;font-weight:600;cursor:pointer;text-align:center;touch-action:manipulation;transition:all .2s}
.oo.on{border-color:var(--or1);color:var(--or1);background:#fff7ed;box-shadow:0 2px 8px rgba(249,115,22,.18)}
.oo:active{opacity:.75}
.m-sub{width:100%;padding:14px;border:none;border-radius:12px;color:#fff;font-size:14px;font-weight:700;cursor:pointer;touch-action:manipulation;min-height:50px;background:linear-gradient(-45deg,var(--or1),var(--or2),var(--or3),var(--or1));background-size:300% 300%;animation:ga 4s ease infinite;box-shadow:0 4px 16px rgba(249,115,22,.35)}
.m-sub:active{transform:scale(.97)}
.sres{background:var(--bg3);border:1.5px solid var(--bd);border-radius:10px;margin-bottom:10px;max-height:150px;overflow-y:auto}
.sri2{padding:9px 12px;border-bottom:1px solid var(--bd);cursor:pointer}
.sri2:last-child{border-bottom:none}
.sri2:active{background:var(--bg)}
.sri2 h4{font-size:13px;color:var(--txt);font-weight:600}
.sri2 p{font-size:10px;color:var(--txt3);margin-top:2px}
.sel-st{background:#fff7ed;border:1.5px solid #fed7aa;border-radius:10px;padding:9px 12px;font-size:13px;color:var(--or2);margin-bottom:10px;font-weight:600}
#toast{position:fixed;bottom:calc(68px + env(safe-area-inset-bottom,0px));left:50%;transform:translateX(-50%);background:var(--txt);color:#fff;padding:11px 22px;border-radius:50px;font-size:13px;z-index:5000;opacity:0;pointer-events:none;transition:opacity .3s;max-width:calc(100vw - 28px);text-align:center;white-space:nowrap;box-shadow:var(--shl)}
#toast.show{opacity:1}
.leaflet-top,.leaflet-bottom{z-index:800!important}
.leaflet-control-attribution{font-size:9px!important;background:rgba(255,255,255,.85)!important}
</style>
</head>
<body>
<div id="app">
<div id="hdr">
  <div id="hdr-top">
    <div class="logo">
      <div class="logo-ic"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><path d="M3 22V9l9-7 9 7v13"/><path d="M14 22v-7H10v7"/><path d="M9 9h6v5H9z"/></svg></div>
      <div class="logo-tx"><h1>CTG <span>Fuel</span> Tracker</h1><p>by Avrojit Chowdhury Ovi</p></div>
    </div>
    <div class="hdr-r">
      <div class="live-b"><div class="live-d"></div>Live: <span id="lc">0</span></div>
      <button class="rep-btn" onclick="openRM()"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>রিপোর্ট দিন</button>
    </div>
  </div>
  <div id="stats">
    <div class="si"><span style="font-size:15px">⛽</span><div><div class="si-v" id="ss">—</div><div class="si-l">স্টেশন</div></div></div>
    <div class="si"><span style="font-size:15px">📋</span><div><div class="si-v" id="sr">—</div><div class="si-l">রিপোর্ট</div></div></div>
    <div class="si"><span style="font-size:15px">👥</span><div><div class="si-v" id="su">—</div><div class="si-l">ব্যবহারকারী</div></div></div>
    <div class="si"><span style="font-size:15px">📈</span><div><div class="si-v" id="sp">—</div><div class="si-l">গড় অকটেন</div></div></div>
  </div>
</div>
<div id="mapw">
  <div id="map"></div>
  <div class="map-leg">
    <div class="ml"><div class="mld" style="background:#22c55e"></div>লাইন নেই</div>
    <div class="ml"><div class="mld" style="background:#f59e0b"></div>অল্প লাইন</div>
    <div class="ml"><div class="mld" style="background:#ef4444"></div>অনেক লাইন</div>
    <div class="ml"><div class="mld" style="background:#6b7280"></div>তেল নেই</div>
  </div>
  <button class="add-fab" onclick="openAM()" title="পাম্প যোগ করুন"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg></button>
</div>
<div id="bs" class="col">
  <div class="bs-hr" onclick="toggleBS()">
    <div><div class="bs-tt"><div class="bs-rd"></div><span class="bs-h3">সাম্প্রতিক রিপোর্টসমূহ</span></div><div class="bs-sb">উপরে টানুন বা ট্যাপ করুন</div></div>
    <span class="bs-ar">⌃</span>
  </div>
  <div class="bs-ct">
    <div class="sw"><span class="sic">🔍</span><input type="text" class="sri" id="si" placeholder="স্টেশনের নাম দিয়ে খুঁজুন..." oninput="renderFeed()"/></div>
    <div class="fts">
      <div class="ft on" onclick="setF('all',this)">সব</div>
      <div class="ft" onclick="setF('none',this)">লাইন নেই</div>
      <div class="ft" onclick="setF('mid',this)">লাইন অল্প</div>
      <div class="ft" onclick="setF('many',this)">লাইন অনেক</div>
      <div class="ft" onclick="setF('unavailable',this)">দিচ্ছে না</div>
    </div>
  </div>
  <div id="feed"></div>
</div>
</div>

<div id="dp">
  <div class="dp-hd">
    <button class="dp-bk" onclick="closeDP()">←</button>
    <div class="dp-tt" id="dp-tt">স্টেশন</div>
    <button class="dp-rb" onclick="openRM(curSid)">+ রিপোর্ট</button>
  </div>
  <div class="dp-body" id="dp-body"></div>
</div>

<div id="rm" class="modal-bg" onclick="if(event.target===this)closeRM()">
  <div class="modal-sh" onclick="event.stopPropagation()">
    <div class="m-hndle"></div>
    <div class="m-hd">রিপোর্ট দিন <button class="m-cl" onclick="closeRM()">✕</button></div>
    <span class="m-lbl">স্টেশন বেছে নিন *</span>
    <input type="text" class="m-inp" id="rms" placeholder="স্টেশনের নাম লিখুন..." oninput="rmSearch()"/>
    <div id="rm-res" class="sres" style="display:none"></div>
    <div id="rm-sel" class="sel-st" style="display:none"></div>
    <span class="m-lbl">তেলের অবস্থা</span>
    <div class="og" id="og-st">
      <div class="oo on" data-v="available" onclick="selO(this,'og-st')">✅ তেল আছে</div>
      <div class="oo" data-v="limited" onclick="selO(this,'og-st')">🟡 সীমিত</div>
      <div class="oo" data-v="unavailable" onclick="selO(this,'og-st')">❌ নেই</div>
      <div class="oo" data-v="unknown" onclick="selO(this,'og-st')">❓ অজানা</div>
    </div>
    <span class="m-lbl">লাইনের অবস্থা</span>
    <div class="og" id="og-ser">
      <div class="oo on" data-v="none" onclick="selO(this,'og-ser')">😊 লাইন নেই</div>
      <div class="oo" data-v="mid" onclick="selO(this,'og-ser')">🟡 অল্প লাইন</div>
      <div class="oo" data-v="many" onclick="selO(this,'og-ser')">😰 অনেক লাইন</div>
      <div class="oo" data-v="unknown" onclick="selO(this,'og-ser')">❓ জানি না</div>
    </div>
    <span class="m-lbl">মন্তব্য (ঐচ্ছিক)</span>
    <textarea class="m-inp" id="rm-nt" rows="2" placeholder="আপনার অভিজ্ঞতা লিখুন..."></textarea>
    <button class="m-sub" onclick="submitRep()">রিপোর্ট জমা দিন →</button>
  </div>
</div>

<div id="am" class="modal-bg" onclick="if(event.target===this)closeAM()">
  <div class="modal-sh" onclick="event.stopPropagation()">
    <div class="m-hndle"></div>
    <div class="m-hd">নতুন পাম্প যোগ করুন <button class="m-cl" onclick="closeAM()">✕</button></div>
    <div id="am-li" style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:9px;padding:9px 12px;font-size:12px;color:#1d4ed8;margin-bottom:12px">📍 আপনার অবস্থান নেওয়া হচ্ছে...</div>
    <span id="am-latl" class="m-lbl" style="display:none">Latitude</span>
    <input type="number" class="m-inp" id="am-lat" placeholder="22.3569" step="0.00001" style="display:none"/>
    <span id="am-lngl" class="m-lbl" style="display:none">Longitude</span>
    <input type="number" class="m-inp" id="am-lng" placeholder="91.7832" step="0.00001" style="display:none"/>
    <span class="m-lbl">পাম্পের নাম *</span>
    <input type="text" class="m-inp" id="am-nm" placeholder="রহিম ফিলিং স্টেশন"/>
    <span class="m-lbl">ঠিকানা</span>
    <input type="text" class="m-inp" id="am-ad" placeholder="কদমতলী, চট্টগ্রাম"/>
    <span class="m-lbl">সার্বিক অবস্থা</span>
    <div class="og" id="og-ast"><div class="oo on" data-v="available" onclick="selO(this,'og-ast')">✅ তেল আছে</div><div class="oo" data-v="limited" onclick="selO(this,'og-ast')">🟡 সীমিত</div><div class="oo" data-v="unavailable" onclick="selO(this,'og-ast')">❌ নেই</div><div class="oo" data-v="unknown" onclick="selO(this,'og-ast')">❓ অজানা</div></div>
    <span class="m-lbl">সিরিয়াল অবস্থা</span>
    <div class="og" id="og-aser"><div class="oo on" data-v="none" onclick="selO(this,'og-aser')">😊 লাইন নেই</div><div class="oo" data-v="mid" onclick="selO(this,'og-aser')">🟡 অল্প</div><div class="oo" data-v="many" onclick="selO(this,'og-aser')">😰 অনেক</div><div class="oo" data-v="unknown" onclick="selO(this,'og-aser')">❓ অজানা</div></div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px">
      <?php foreach(['অকটেন'=>'okthen','পেট্রোল'=>'petrol','ডিজেল'=>'diesel'] as $f=>$k): ?>
      <div style="background:var(--bg3);border:1.5px solid var(--bd);border-radius:10px;padding:10px 8px">
        <div style="font-size:11px;font-weight:700;color:var(--txt);margin-bottom:7px"><?=$f?></div>
        <select class="m-inp" id="am-s-<?=$k?>" style="margin-bottom:5px;padding:6px 8px;font-size:11px"><option value="আছে">আছে</option><option value="সীমিত">সীমিত</option><option value="নেই">নেই</option><option value="প্রযোজ্য নয়">N/A</option></select>
        <input type="number" class="m-inp" id="am-p-<?=$k?>" placeholder="দাম ৳" style="padding:6px 8px;font-size:11px;margin-bottom:0" inputmode="decimal"/>
      </div>
      <?php endforeach; ?>
    </div>
    <button class="m-sub" onclick="submitAM()" style="background:linear-gradient(-45deg,var(--bl1),var(--bl2),#60a5fa,var(--bl1));background-size:300% 300%;animation:ga 5s ease infinite;box-shadow:0 4px 16px rgba(59,130,246,.3)">পাম্প যোগ করুন →</button>
  </div>
</div>

<div id="toast"></div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<script>
let map,markers={},allSt=[],allRep=[],curF='all',curSid=null,rmSid=null,amLat=null,amLng=null,toastT;
const SC={available:'তেল আছে',limited:'সীমিত',unavailable:'দিচ্ছে না',unknown:'অজানা'};
const SER={none:'😊 লাইন নেই',mid:'🟡 অল্প লাইন',many:'😰 অনেক লাইন',unknown:'❓ অজানা'};
const CC={available:'cg',limited:'ca',unavailable:'cr',unknown:'ck'};
const CS={none:'cg',mid:'ca',many:'cr',unknown:'ck'};
const FUELS=[{bn:'অকটেন',k:'okthen'},{bn:'পেট্রোল',k:'petrol'},{bn:'ডিজেল',k:'diesel'}];

function initMap(){
  map=L.map('map',{zoomControl:false}).setView([22.3569,91.7832],13);
  L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',{
    attribution:'© <a href="https://openstreetmap.org">OSM</a> © <a href="https://carto.com">CARTO</a>',subdomains:'abcd',maxZoom:19
  }).addTo(map);
  L.control.zoom({position:'topright'}).addTo(map);
}

function mkIcon(status){
  const cfg={
    available:{c:'#22c55e',glow:'rgba(34,197,94,0.5)',badge:'✓',bc:'#16a34a',animate:true},
    limited:{c:'#f59e0b',glow:'rgba(245,158,11,0.5)',badge:'!',bc:'#d97706',animate:true},
    unavailable:{c:'#ef4444',glow:'rgba(239,68,68,0.4)',badge:'✕',bc:'#dc2626',animate:false},
    unknown:{c:'#6b7280',glow:'rgba(107,114,128,0.3)',badge:'?',bc:'#4b5563',animate:false}
  };
  const d=cfg[status]||cfg.unknown;
  const anim=d.animate?`style="animation:bounce 2.5s ease-in-out infinite"`:'';
  const ring=d.animate?`<ellipse cx="18" cy="43" rx="12" ry="4" fill="${d.glow}" style="animation:ping 2s ease-out infinite;transform-origin:18px 43px"/>
  <ellipse cx="18" cy="43" rx="8" ry="2.5" fill="${d.glow}" style="animation:ping 2s ease-out .6s infinite;transform-origin:18px 43px"/>`:'';
  const shadow='<filter id="ds"><feDropShadow dx="0" dy="3" stdDeviation="3" flood-color="rgba(0,0,0,0.22)"/></filter>';
  const gf=`<filter id="gf"><feGaussianBlur stdDeviation="3" result="b"/><feComposite in="SourceGraphic" in2="b" operator="over"/></filter>`;
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="36" height="48" viewBox="0 0 36 48">
    <defs>${shadow}${gf}
    <style>@keyframes bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}}@keyframes ping{0%{transform:scale(1);opacity:.65}100%{transform:scale(2.8);opacity:0}}</style>
    <linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="white" stop-opacity=".4"/><stop offset="1" stop-color="transparent"/></linearGradient>
    </defs>
    <g ${anim}>
      ${ring}
      <ellipse cx="18" cy="44" rx="9" ry="3" fill="rgba(0,0,0,0.13)"/>
      <path d="M18 1C10.3 1 4 7.3 4 15c0 10.5 14 30 14 30s14-19.5 14-30C32 7.3 25.7 1 18 1z" fill="${d.c}" filter="url(#ds)"/>
      <path d="M18 1C10.3 1 4 7.3 4 15c0 10.5 14 30 14 30s14-19.5 14-30C32 7.3 25.7 1 18 1z" fill="url(#lg)"/>
      <circle cx="18" cy="15" r="9.5" fill="white" fill-opacity=".95"/>
      <text x="18" y="19.5" text-anchor="middle" font-size="11" font-family="system-ui">⛽</text>
      <circle cx="27" cy="6" r="5.5" fill="${d.bc}" stroke="white" stroke-width="1.5"/>
      <text x="27" y="9.8" text-anchor="middle" font-size="8" fill="white" font-weight="bold" font-family="system-ui">${d.badge}</text>
    </g>
  </svg>`;
  return L.divIcon({className:'',html:svg,iconSize:[36,48],iconAnchor:[18,48]});
}

function fc(av){return av==='আছে'?'#22c55e':av==='সীমিত'?'#f59e0b':av==='নেই'?'#ef4444':'#6b7280';}
function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}

async function loadSt(){
  try{const r=await fetch('/api/stations.php');const d=await r.json();if(!d.success)return;allSt=d.stations;
  document.getElementById('ss').textContent=d.stations.length;document.getElementById('lc').textContent=d.stations.length;
  Object.values(markers).forEach(m=>map.removeLayer(m));markers={};
  d.stations.forEach(s=>{const m=L.marker([s.lat,s.lng],{icon:mkIcon(s.status)}).addTo(map).on('click',()=>openDP(s.id));markers[s.id]=m;});
  }catch(e){}
}
async function loadRep(){
  try{const r=await fetch('/api/reports.php');const d=await r.json();if(!d.success)return;allRep=d.reports;
  document.getElementById('sr').textContent=d.total||d.reports.length;document.getElementById('su').textContent=d.unique_users||'—';document.getElementById('sp').textContent=d.avg_price?'৳'+d.avg_price:'—';
  renderFeed();}catch(e){}
}
function renderFeed(){
  const q=document.getElementById('si').value.toLowerCase();
  let list=allRep.filter(r=>{
    if(curF==='unavailable'&&r.status!=='unavailable')return false;
    if(curF!=='all'&&curF!=='unavailable'&&r.serial_status!==curF)return false;
    if(q&&!r.station_name.toLowerCase().includes(q))return false;
    return true;
  });
  const feed=document.getElementById('feed');
  if(!list.length){feed.innerHTML='<div class="emp">কোনো রিপোর্ট নেই।</div>';return;}
  feed.innerHTML=list.slice(0,60).map(r=>`<div class="rc">
    <div class="rc-ic">⛽</div>
    <div class="rc-bd">
      <div class="rc-nm">${esc(r.station_name)}</div>
      <div class="rc-mt">${esc(r.time_ago||r.created_at)} · সহায়তায়: <span>${esc(r.reporter||'user')}</span></div>
      ${r.note?`<div class="rc-nt">${esc(r.note)}</div>`:''}
      <div class="rc-ac"><div class="rb">👍 সঠিক (${r.upvotes||0})</div><div class="rb">👎 ভুল (${r.downvotes||0})</div><div class="rb mp" onclick="goSt(${r.station_id})">📍 ম্যাপ</div></div>
    </div>
    <div class="rc-rt">
      <div class="ch ${CC[r.status]||'ck'}">${SC[r.status]||'অজানা'}</div>
      <div class="ch ${CS[r.serial_status]||'ck'}" style="font-size:9px">${SER[r.serial_status]||'অজানা'}</div>
      ${r.price?`<div class="pb">৳${r.price}</div><div class="pl">অকটেন</div>`:''}
    </div>
  </div>`).join('');
}
function setF(f,el){curF=f;document.querySelectorAll('.ft').forEach(t=>t.classList.remove('on'));el.classList.add('on');renderFeed();}
function goSt(sid){const s=allSt.find(x=>x.id==sid);if(s){map.flyTo([s.lat,s.lng],16,{duration:1.2});document.getElementById('bs').classList.replace('exp','col');}}

async function openDP(id){
  curSid=id;
  document.getElementById('dp-tt').textContent='লোড হচ্ছে...';
  document.getElementById('dp-body').innerHTML='<div style="text-align:center;padding:50px;font-size:24px">⏳</div>';
  document.getElementById('dp').classList.add('open');
  const r=await fetch('/api/stations.php?id='+id);const d=await r.json();
  if(!d.success){toast('লোড ব্যর্থ।');return;}
  const s=d.station;
  document.getElementById('dp-tt').textContent=s.name;
  const S2={available:'✅ তেল আছে',limited:'🟡 সীমিত',unavailable:'❌ দিচ্ছে না',unknown:'❓ অজানা'};
  const SE2={none:'😊 লাইন নেই',mid:'🟡 অল্প লাইন',many:'😰 অনেক লাইন',unknown:'❓ অজানা'};
  const fcds=(s.fuels||[]).map(f=>`<div class="fc"><div class="fc-n">${f.fuel_type}</div><div class="fc-s" style="color:${fc(f.availability||'')}">${f.availability||'—'}</div><div class="fc-p">${f.price?'৳'+parseFloat(f.price).toFixed(0):'—'}</div></div>`).join('');
  const sugg=(['অকটেন','পেট্রোল','ডিজেল']).map(f=>{const k='ps_'+f.replace(/[^\w]/g,'_');const ex=s.pending_suggests&&s.pending_suggests.includes(f);
    return`<div style="background:var(--bg3);border:1.5px solid var(--bd);border-radius:10px;padding:11px;margin-bottom:8px">
      <div style="font-size:12px;font-weight:700;color:var(--txt);margin-bottom:8px">${f}${ex?` <span class="ptag">⏳ বাকি</span>`:''}</div>
      ${ex?'<p style="font-size:11px;color:var(--txt3)">সাজেশন জমা আছে।</p>':`<div class="sgr"><div><div style="font-size:10px;color:var(--txt3);margin-bottom:4px">নতুন দাম (৳/লি.)</div><input type="number" class="dp-in" id="${k}" placeholder="132" min="0" step="0.5" inputmode="decimal"/></div><button class="dp-btn dp-or" onclick="subPS(${id},'${f}','${k}')" style="min-height:38px;padding:0 14px;font-size:12px">জমা</button></div>`}
    </div>`;}).join('');
  const reps=(s.reports||[]).length?(s.reports).map(r=>`<div class="rmin"><p>${esc(r.note||'কোনো মন্তব্য নেই')} <span style="float:right;font-size:10px;font-weight:700;color:${r.status==='available'?'#16a34a':r.status==='unavailable'?'#dc2626':'#d97706'}">${SC[r.status]||''}</span></p><time>${r.created_at}</time></div>`).join(''):'<p style="font-size:12px;color:var(--txt3);text-align:center;padding:14px">রিপোর্ট নেই।</p>';
  document.getElementById('dp-body').innerHTML=`
    <div style="display:flex;gap:7px;flex-wrap:wrap;margin-bottom:14px"><span class="ch ${CC[s.status]||'ck'}">${S2[s.status]||'অজানা'}</span><span class="ch ${CS[s.serial_status]||'ck'}">${SE2[s.serial_status]||'অজানা'}</span></div>
    <div class="dp-rw"><span class="dp-l">ঠিকানা</span><span class="dp-v">${esc(s.address||'—')}</span></div>
    <div class="dp-rw"><span class="dp-l">শেষ আপডেট</span><span class="dp-v">${s.last_updated||'—'}</span></div>
    <div class="dp-stl">জ্বালানির অবস্থা ও দাম</div><div class="fg">${fcds}</div>
    <div class="dp-stl">দামের সাজেশন দিন</div>
    <div class="ambox">Admin অনুমোদনের পর সবার জন্য দেখা যাবে।</div>${sugg}
    <div class="dp-stl">সাম্প্রতিক রিপোর্ট</div>${reps}
    ${s.is_user_submitted?'<div style="text-align:center;font-size:10px;color:var(--txt3);margin-top:8px">📍 ব্যবহারকারী কর্তৃক যোগকৃত</div>':''}`;
}
function closeDP(){document.getElementById('dp').classList.remove('open');curSid=null;}

async function subPS(sid,fuel,key){
  const inp=document.getElementById(key);if(!inp||!inp.value.trim()){toast('সঠিক দাম লিখুন!');return;}
  const r=await fetch('/api/suggest_price.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({station_id:sid,fuel_type:fuel,price:inp.value.trim()})});
  const d=await r.json();if(d.success){toast(fuel+' সাজেশন জমা! ✅');openDP(sid);}else toast(d.error||'সমস্যা।');
}

function openRM(sid){
  rmSid=sid||null;document.getElementById('rms').value='';document.getElementById('rm-res').style.display='none';document.getElementById('rm-sel').style.display='none';document.getElementById('rm-nt').value='';
  if(sid){const s=allSt.find(x=>x.id==sid);if(s){document.getElementById('rm-sel').textContent='📍 '+s.name;document.getElementById('rm-sel').style.display='block';}}
  document.getElementById('rm').classList.add('open');
}
function closeRM(){document.getElementById('rm').classList.remove('open');}
function selO(el,gid){document.querySelectorAll('#'+gid+' .oo').forEach(o=>o.classList.remove('on'));el.classList.add('on');}
function getO(gid){return document.querySelector('#'+gid+' .oo.on')?.dataset.v||'';}
function rmSearch(){
  const q=document.getElementById('rms').value.toLowerCase();const res=document.getElementById('rm-res');
  if(!q){res.style.display='none';return;}
  const m=allSt.filter(s=>s.name.toLowerCase().includes(q)).slice(0,7);
  if(!m.length){res.style.display='none';return;}
  res.style.display='block';
  res.innerHTML=m.map(s=>`<div class="sri2" onclick="selSt(${s.id},'${esc(s.name)}')"><h4>${esc(s.name)}</h4><p>${esc(s.address||'')}</p></div>`).join('');
}
function selSt(id,name){rmSid=id;document.getElementById('rm-res').style.display='none';document.getElementById('rm-sel').textContent='📍 '+name;document.getElementById('rm-sel').style.display='block';document.getElementById('rms').value='';}
async function submitRep(){
  if(!rmSid){toast('স্টেশন বেছে নিন!');return;}
  const b={station_id:rmSid,status:getO('og-st'),serial_status:getO('og-ser'),note:document.getElementById('rm-nt').value.trim()};
  const r=await fetch('/api/report.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
  const d=await r.json();
  if(d.success){toast('রিপোর্ট জমা হয়েছে! ✅');closeRM();if(markers[rmSid]){markers[rmSid].setIcon(mkIcon(b.status));}loadRep();}
  else toast(d.error||'সমস্যা।');
}

function openAM(){
  amLat=null;amLng=null;['am-nm','am-ad'].forEach(id=>document.getElementById(id).value='');
  document.getElementById('am').classList.add('open');
  document.getElementById('am-li').textContent='📍 আপনার অবস্থান নেওয়া হচ্ছে...';
  ['am-lat','am-latl','am-lng','am-lngl'].forEach(id=>document.getElementById(id).style.display='none');
  if(!navigator.geolocation){showManFlds();return;}
  navigator.geolocation.getCurrentPosition(pos=>{
    amLat=pos.coords.latitude;amLng=pos.coords.longitude;
    document.getElementById('am-li').textContent='📍 বর্তমান অবস্থান ('+amLat.toFixed(5)+', '+amLng.toFixed(5)+')';
    map.flyTo([amLat,amLng],16,{duration:1.2});
  },()=>showManFlds(),{timeout:7000,enableHighAccuracy:true});
}
function showManFlds(){document.getElementById('am-li').textContent='⚠️ Location পাওয়া যায়নি।';['am-lat','am-latl','am-lng','am-lngl'].forEach(id=>document.getElementById(id).style.display='block');}
function closeAM(){document.getElementById('am').classList.remove('open');}
async function submitAM(){
  const name=document.getElementById('am-nm').value.trim();if(!name){toast('পাম্পের নাম দিন!');return;}
  let la=amLat,ln=amLng;
  if(!la){la=parseFloat(document.getElementById('am-lat').value);ln=parseFloat(document.getElementById('am-lng').value);if(isNaN(la)||isNaN(ln)){toast('সঠিক অবস্থান দিন!');return;}}
  const fuels=FUELS.map(f=>({fuel_type:f.bn,availability:document.getElementById('am-s-'+f.k).value,price:document.getElementById('am-p-'+f.k).value||null}));
  const r=await fetch('/api/add_station.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,address:document.getElementById('am-ad').value.trim(),lat:la,lng:ln,status:getO('og-ast'),serial_status:getO('og-aser'),fuels,is_user_submitted:1})});
  const d=await r.json();if(d.success){toast('"'+name+'" যোগ হয়েছে! ✅');closeAM();loadSt();}else toast(d.error||'সমস্যা।');
}

function toggleBS(){const bs=document.getElementById('bs');bs.classList.contains('col')?bs.classList.replace('col','exp'):bs.classList.replace('exp','col');}
const bs=document.getElementById('bs');let bsY=0;
bs.addEventListener('touchstart',e=>{bsY=e.touches[0].clientY;},{passive:true});
bs.addEventListener('touchend',e=>{const dy=e.changedTouches[0].clientY-bsY;if(dy>60)bs.classList.replace('exp','col');else if(dy<-60)bs.classList.replace('col','exp');},{passive:true});

function toast(msg){clearTimeout(toastT);const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');toastT=setTimeout(()=>t.classList.remove('show'),3500);}
window.addEventListener('resize',()=>map&&map.invalidateSize());
(async()=>{initMap();await loadSt();await loadRep();setInterval(loadRep,60000);})();
</script>
</body>
</html>
