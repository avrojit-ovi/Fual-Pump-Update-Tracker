<?php
session_start();
require_once '../config.php';
requireAdmin();
$page_title = 'Admin ব্যবহারকারী';
$pdo = getDB();
$msg='';$err='';

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $action=$_POST['action']??'';
    if ($action==='add') {
        $uname=trim($_POST['username']??'');
        $fname=trim($_POST['full_name']??'');
        $pw=$_POST['password']??'';
        $role=$_POST['role']??'admin';
        $email=trim($_POST['email']??'');
        if (!$uname||!$fname||!$pw) { $err='সব তথ্য পূরণ করুন।'; }
        elseif (strlen($pw)<8) { $err='পাসওয়ার্ড কমপক্ষে ৮ অক্ষর হতে হবে।'; }
        else {
            $check=$pdo->prepare("SELECT id FROM admin_users WHERE username=?")->execute([$uname]);
            $exists=$pdo->query("SELECT COUNT(*) FROM admin_users WHERE username='".addslashes($uname)."'")->fetchColumn();
            if ($exists) { $err='এই username ইতিমধ্যে ব্যবহৃত।'; }
            else {
                $pdo->prepare("INSERT INTO admin_users(username,password,full_name,email,role) VALUES(?,?,?,?,?)")->execute([$uname,password_hash($pw,PASSWORD_DEFAULT),$fname,$email,$role]);
                $msg='নতুন Admin যোগ করা হয়েছে!';
            }
        }
    } elseif ($action==='toggle') {
        $id=intval($_POST['id']??0);
        if ($id!==$_SESSION['admin_id']) {
            $pdo->prepare("UPDATE admin_users SET is_active=NOT is_active WHERE id=?")->execute([$id]);
            $msg='অবস্থা পরিবর্তন করা হয়েছে।';
        }
    } elseif ($action==='change_password') {
        $id=intval($_POST['id']??0);
        $pw=$_POST['new_password']??'';
        if (strlen($pw)<8) { $err='পাসওয়ার্ড কমপক্ষে ৮ অক্ষর হতে হবে।'; }
        else { $pdo->prepare("UPDATE admin_users SET password=? WHERE id=?")->execute([password_hash($pw,PASSWORD_DEFAULT),$id]);$msg='পাসওয়ার্ড পরিবর্তন হয়েছে!'; }
    }
}

$users=$pdo->query("SELECT * FROM admin_users ORDER BY id")->fetchAll();
include '_header.php';
?>
  <div class="topbar">
    <div><h1>Admin ব্যবহারকারী</h1><div class="breadcrumb">Admin অ্যাকাউন্ট ম্যানেজ করুন</div></div>
  </div>
  <div class="content">
    <?php if($msg): ?><div class="alert alert-success">✓ <?=sanitize($msg)?></div><?php endif; ?>
    <?php if($err): ?><div class="alert alert-error">✕ <?=sanitize($err)?></div><?php endif; ?>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
      <div class="card">
        <div class="card-header"><span class="card-title">নতুন Admin যোগ করুন</span></div>
        <div style="padding:20px">
        <form method="POST">
          <input type="hidden" name="action" value="add">
          <div class="form-group"><label class="form-label">Full Name *</label><input name="full_name" class="form-control" placeholder="Avrojit Chowdhury" required></div>
          <div class="form-group"><label class="form-label">Username *</label><input name="username" class="form-control" placeholder="admin2" required></div>
          <div class="form-group"><label class="form-label">Email</label><input name="email" type="email" class="form-control" placeholder="admin@email.com"></div>
          <div class="form-group"><label class="form-label">Password * (কমপক্ষে ৮ অক্ষর)</label><input name="password" type="password" class="form-control" placeholder="••••••••" required></div>
          <div class="form-group"><label class="form-label">Role</label>
            <select name="role" class="form-control">
              <option value="admin">Admin</option>
              <option value="superadmin">Super Admin</option>
            </select>
          </div>
          <button type="submit" class="btn btn-g" style="padding:10px 20px;font-size:13px">Admin যোগ করুন</button>
        </form>
        </div>
      </div>

      <div class="card">
        <div class="card-header"><span class="card-title">বিদ্যমান Admin (<?=count($users)?>)</span></div>
        <table>
          <thead><tr><th>নাম</th><th>Username</th><th>Role</th><th>অবস্থা</th><th>অ্যাকশন</th></tr></thead>
          <tbody>
          <?php foreach($users as $u): ?>
          <tr>
            <td style="color:#e2e8f0;font-weight:500"><?=sanitize($u['full_name'])?></td>
            <td style="font-size:12px;color:rgba(255,255,255,.5)"><?=sanitize($u['username'])?></td>
            <td><span class="badge <?=$u['role']==='superadmin'?'b-p':'b-k?>'?>"><?=$u['role']?></span></td>
            <td><span class="badge <?=$u['is_active']?'b-g':'b-r?>'?>"><?=$u['is_active']?'সক্রিয়':'নিষ্ক্রিয়'?></span></td>
            <td>
              <?php if($u['id']!==$_SESSION['admin_id']): ?>
              <form method="POST" style="display:inline">
                <input type="hidden" name="action" value="toggle">
                <input type="hidden" name="id" value="<?=$u['id']?>">
                <button type="submit" class="btn <?=$u['is_active']?'btn-r':'btn-g'?>" style="padding:4px 10px;font-size:11px"><?=$u['is_active']?'নিষ্ক্রিয়':'সক্রিয়'?></button>
              </form>
              <?php endif; ?>
              <button class="btn btn-b" style="padding:4px 10px;font-size:11px" onclick="showPwForm(<?=$u['id']?>)">PW</button>
              <div id="pw-<?=$u['id']?>" style="display:none;margin-top:8px">
                <form method="POST" style="display:flex;gap:6px">
                  <input type="hidden" name="action" value="change_password">
                  <input type="hidden" name="id" value="<?=$u['id']?>">
                  <input type="password" name="new_password" class="form-control" placeholder="নতুন পাসওয়ার্ড" style="margin-bottom:0;font-size:12px;padding:6px 10px">
                  <button type="submit" class="btn btn-g" style="padding:6px 10px;font-size:11px">✓</button>
                </form>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="credit-bar">CTG Fuel Tracker v1.0 &mdash; Developed by <a href="https://www.facebook.com/avrojit.ovi/" target="_blank">Avrojit Chowdhury Ovi</a></div>
</div>
<script>function showPwForm(id){var d=document.getElementById('pw-'+id);d.style.display=d.style.display==='none'?'block':'none';}</script>
</body></html>
