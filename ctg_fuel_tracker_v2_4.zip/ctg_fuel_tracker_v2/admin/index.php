<?php
session_start();
require_once '../config.php';
requireAdmin();
$page_title = 'ড্যাশবোর্ড';
$pdo = getDB();

$stats = [
    'total' => $pdo->query("SELECT COUNT(*) FROM stations WHERE is_active=1")->fetchColumn(),
    'available' => $pdo->query("SELECT COUNT(*) FROM stations WHERE status='available' AND is_active=1")->fetchColumn(),
    'unavailable' => $pdo->query("SELECT COUNT(*) FROM stations WHERE status='unavailable' AND is_active=1")->fetchColumn(),
    'pending' => $pdo->query("SELECT COUNT(*) FROM price_suggestions WHERE status='pending'")->fetchColumn(),
    'reports_today' => $pdo->query("SELECT COUNT(*) FROM reports WHERE DATE(created_at)=CURDATE()")->fetchColumn(),
    'user_submitted' => $pdo->query("SELECT COUNT(*) FROM stations WHERE is_user_submitted=1 AND is_active=1")->fetchColumn(),
];
$recent_reports = $pdo->query("SELECT r.*, s.name as station_name FROM reports r LEFT JOIN stations s ON r.station_id=s.id ORDER BY r.id DESC LIMIT 8")->fetchAll();
$pending_suggests = $pdo->query("SELECT ps.*, s.name as station_name FROM price_suggestions ps LEFT JOIN stations s ON ps.station_id=s.id WHERE ps.status='pending' ORDER BY ps.id ASC LIMIT 5")->fetchAll();

include '_header.php';
?>
  <div class="topbar">
    <div>
      <h1>ড্যাশবোর্ড</h1>
      <div class="breadcrumb">স্বাগতম, <?= sanitize($_SESSION['admin_name']??'') ?></div>
    </div>
    <span style="font-size:12px;color:rgba(255,255,255,.35)"><?= date('d M Y, h:i A') ?></span>
  </div>
  <div class="content">
    <div class="stat-grid">
      <div class="stat-card"><div class="label">মোট পাম্প</div><div class="value"><?= $stats['total'] ?></div><div class="sub">সক্রিয় পাম্প</div></div>
      <div class="stat-card"><div class="label">তেল আছে</div><div class="value" style="color:#22c55e"><?= $stats['available'] ?></div><div class="sub">পাম্প</div></div>
      <div class="stat-card"><div class="label">তেল নেই</div><div class="value" style="color:#ef4444"><?= $stats['unavailable'] ?></div><div class="sub">পাম্প</div></div>
      <div class="stat-card"><div class="label">অনুমোদন বাকি</div><div class="value" style="color:#f59e0b"><?= $stats['pending'] ?></div><div class="sub">দামের সাজেশন</div></div>
      <div class="stat-card"><div class="label">আজকের রিপোর্ট</div><div class="value"><?= $stats['reports_today'] ?></div><div class="sub">ব্যবহারকারী রিপোর্ট</div></div>
      <div class="stat-card"><div class="label">User যোগকৃত</div><div class="value"><?= $stats['user_submitted'] ?></div><div class="sub">পাম্প</div></div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
      <div class="card">
        <div class="card-header">
          <span class="card-title">⏳ অনুমোদন বাকি দামের সাজেশন</span>
          <a href="/admin/approve.php" class="btn btn-o">সব দেখুন</a>
        </div>
        <?php if($pending_suggests): ?>
        <table>
          <thead><tr><th>পাম্প</th><th>জ্বালানি</th><th>দাম</th><th>অ্যাকশন</th></tr></thead>
          <tbody>
          <?php foreach($pending_suggests as $p): ?>
          <tr>
            <td style="color:#e2e8f0"><?= sanitize($p['station_name']) ?></td>
            <td><?= sanitize($p['fuel_type']) ?></td>
            <td><span class="badge b-p">৳<?= number_format($p['suggested_price'],0) ?>/লি.</span></td>
            <td>
              <a href="/admin/approve.php?approve=<?= $p['id'] ?>" class="btn btn-g" style="padding:5px 10px;font-size:11px">✓</a>
              <a href="/admin/approve.php?reject=<?= $p['id'] ?>" class="btn btn-r" style="padding:5px 10px;font-size:11px">✕</a>
            </td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
        <?php else: ?>
        <div style="padding:24px;text-align:center;color:rgba(255,255,255,.3);font-size:13px">কোনো অনুমোদন বাকি নেই ✓</div>
        <?php endif; ?>
      </div>

      <div class="card">
        <div class="card-header">
          <span class="card-title">📋 সাম্প্রতিক রিপোর্ট</span>
          <a href="/admin/reports.php" class="btn btn-b">সব দেখুন</a>
        </div>
        <?php if($recent_reports): ?>
        <table>
          <thead><tr><th>পাম্প</th><th>অবস্থা</th><th>সময়</th></tr></thead>
          <tbody>
          <?php foreach($recent_reports as $r):
            $bc=['available'=>'b-g','limited'=>'b-a','unavailable'=>'b-r'][$r['status']]??'b-k';
            $bl=['available'=>'তেল আছে','limited'=>'সীমিত','unavailable'=>'নেই','unknown'=>'অজানা'][$r['status']]??'অজানা';
          ?>
          <tr>
            <td style="color:#e2e8f0"><?= sanitize($r['station_name']) ?></td>
            <td><span class="badge <?= $bc ?>"><?= $bl ?></span></td>
            <td style="font-size:11px;color:rgba(255,255,255,.4)"><?= date('d M, h:i A', strtotime($r['created_at'])) ?></td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
        <?php else: ?>
        <div style="padding:24px;text-align:center;color:rgba(255,255,255,.3);font-size:13px">কোনো রিপোর্ট নেই।</div>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <div class="credit-bar">CTG Fuel Tracker v1.0 &mdash; Developed by <a href="https://www.facebook.com/avrojit.ovi/" target="_blank">Avrojit Chowdhury Ovi</a></div>
</div>
</body>
</html>
