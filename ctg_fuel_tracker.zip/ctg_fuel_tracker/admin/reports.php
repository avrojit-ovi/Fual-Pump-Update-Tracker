<?php
session_start();
require_once '../config.php';
requireAdmin();
$page_title = 'ব্যবহারকারী রিপোর্ট';
$pdo = getDB();
$reports=$pdo->query("SELECT r.*,s.name as station_name FROM reports r LEFT JOIN stations s ON r.station_id=s.id ORDER BY r.id DESC LIMIT 200")->fetchAll();
include '_header.php';
?>
  <div class="topbar"><div><h1>ব্যবহারকারী রিপোর্ট</h1><div class="breadcrumb">সকল রিপোর্টের তালিকা</div></div></div>
  <div class="content">
    <div class="card">
      <div class="card-header"><span class="card-title"><?=count($reports)?>টি রিপোর্ট</span></div>
      <?php if($reports): ?>
      <table>
        <thead><tr><th>#</th><th>পাম্প</th><th>অবস্থা</th><th>সিরিয়াল</th><th>মন্তব্য</th><th>IP</th><th>সময়</th></tr></thead>
        <tbody>
        <?php foreach($reports as $r):
          $sb=['available'=>'b-g','limited'=>'b-a','unavailable'=>'b-r'][$r['status']]??'b-k';
          $sl=['available'=>'তেল আছে','limited'=>'সীমিত','unavailable'=>'নেই','unknown'=>'অজানা'][$r['status']]??'অজানা';
          $seri=['none'=>'নেই','mid'=>'মাঝারি','many'=>'বেশি','unknown'=>'অজানা'][$r['serial_status']]??'অজানা';
        ?>
        <tr>
          <td style="color:rgba(255,255,255,.3)"><?=$r['id']?></td>
          <td style="color:#e2e8f0;font-weight:500"><?=sanitize($r['station_name'])?></td>
          <td><span class="badge <?=$sb?>"><?=$sl?></span></td>
          <td style="font-size:12px;color:rgba(255,255,255,.5)"><?=$seri?></td>
          <td style="font-size:12px;color:rgba(255,255,255,.5);max-width:200px"><?=sanitize(mb_substr($r['note']??'—',0,60))?></td>
          <td style="font-size:11px;color:rgba(255,255,255,.3)"><?=$r['reporter_ip']?></td>
          <td style="font-size:11px;color:rgba(255,255,255,.4)"><?=date('d M, h:i A',strtotime($r['created_at']))?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <?php else: ?>
      <div style="padding:40px;text-align:center;color:rgba(255,255,255,.3)">কোনো রিপোর্ট নেই।</div>
      <?php endif; ?>
    </div>
  </div>
  <div class="credit-bar">CTG Fuel Tracker v1.0 &mdash; Developed by <a href="https://www.facebook.com/avrojit.ovi/" target="_blank">Avrojit Chowdhury Ovi</a></div>
</div></body></html>
