<?php
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CTG Fuel Tracker — চট্টগ্রাম জ্বালানি ট্র্যাকার</title>
<meta name="description" content="চট্টগ্রামের ফুয়েল পাম্পে তেলের অবস্থা ও দাম রিয়েলটাইমে দেখুন">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css"/>
<style>
*{box-sizing:border-box;margin:0;padding:0}
@keyframes grad{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}
@keyframes fadeUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
body{font-family:'Segoe UI',system-ui,sans-serif;background:#0a0f1e;overflow:hidden}
#app{position:relative;width:100vw;height:100vh;overflow:hidden}
#map{width:100%;height:100%}

/* Topbar */
#topbar{position:absolute;top:12px;left:50%;transform:translateX(-50%);z-index:900;background:rgba(10,15,30,0.94);backdrop-filter:blur(8px);border:1px solid rgba(255,255,255,0.12);border-radius:50px;padding:9px 20px;display:flex;align-items:center;gap:12px;box-shadow:0 4px 24px rgba(0,0,0,.4);white-space:nowrap}
#topbar .logo{display:flex;align-items:center;gap:8px}
#topbar h1{font-size:14px;font-weight:600;color:#fff;letter-spacing:0.02em}
#topbar h1 span{color:#22c55e}
#pump-count{font-size:11px;color:rgba(255,255,255,0.5);background:rgba(255,255,255,0.08);padding:3px 10px;border-radius:20px}

/* Legend */
.legend{position:absolute;bottom:90px;left:12px;z-index:900;background:rgba(10,15,30,0.9);backdrop-filter:blur(8px);border:1px solid rgba(255,255,255,0.1);border-radius:12px;padding:10px 14px}
.leg{display:flex;align-items:center;gap:8px;font-size:11px;color:rgba(255,255,255,0.7);margin-bottom:5px}
.leg:last-child{margin-bottom:0}
.dot{width:11px;height:11px;border-radius:50%;flex-shrink:0;border:1.5px solid rgba(255,255,255,0.3)}

/* FABs */
#fabs{position:absolute;bottom:16px;left:50%;transform:translateX(-50%);z-index:900;display:flex;gap:8px}
.fab{position:relative;padding:10px 20px;border-radius:50px;border:none;font-size:13px;font-weight:600;cursor:pointer;color:#fff;white-space:nowrap;box-shadow:0 4px 16px rgba(0,0,0,.35);background:linear-gradient(-45deg,#065f46,#0f766e,#166534,#064e3b);background-size:300% 300%;animation:grad 4s ease infinite;transition:transform .15s,opacity .15s}
.fab:hover{transform:translateY(-1px);opacity:.92}
.fab-admin{background:linear-gradient(-45deg,#1e3a5f,#1e40af,#312e81,#0f172a);background-size:300% 300%;animation:grad 5s ease infinite}
.fab-badge{position:absolute;top:-7px;right:-7px;background:#ef4444;color:#fff;font-size:10px;font-weight:700;border-radius:50px;min-width:19px;height:19px;display:none;align-items:center;justify-content:center;padding:0 5px;border:2px solid #0a0f1e}

/* Panel */
#panel{position:absolute;z-index:1000;background:linear-gradient(-45deg,#0a0f1e,#0d2137,#0a1f18,#12100e);background-size:400% 400%;animation:grad 10s ease infinite;display:flex;flex-direction:column;transition:transform .28s cubic-bezier(.4,0,.2,1);border:1px solid rgba(255,255,255,0.08)}
#panel.desktop{top:0;right:0;width:340px;height:100%;transform:translateX(100%);border-radius:0;border-left-color:rgba(255,255,255,0.1)}
#panel.desktop.open{transform:translateX(0)}
#panel.mobile{bottom:0;left:0;right:0;width:100%;height:76%;transform:translateY(100%);border-radius:20px 20px 0 0}
#panel.mobile.open{transform:translateY(0)}

.ph{padding:14px 16px;border-bottom:1px solid rgba(255,255,255,0.08);display:flex;align-items:center;justify-content:space-between;flex-shrink:0;position:sticky;top:0;z-index:2;background:rgba(0,0,0,0.4);backdrop-filter:blur(8px)}
.ph-title{font-size:14px;font-weight:600;color:#fff;display:flex;align-items:center;gap:8px}
.ph-close{background:rgba(255,255,255,0.1);border:none;border-radius:8px;width:30px;height:30px;cursor:pointer;color:rgba(255,255,255,0.7);font-size:16px;display:flex;align-items:center;justify-content:center}
.ph-close:hover{background:rgba(255,255,255,0.2);color:#fff}
.pb{padding:16px;flex:1;overflow-y:auto}

/* Badges */
.badge{display:inline-flex;align-items:center;gap:5px;padding:4px 12px;border-radius:50px;font-size:12px;font-weight:500;border:1px solid}
.badge-g{background:rgba(34,197,94,.18);color:#86efac;border-color:rgba(34,197,94,.4)}
.badge-a{background:rgba(245,158,11,.18);color:#fcd34d;border-color:rgba(245,158,11,.4)}
.badge-r{background:rgba(239,68,68,.18);color:#fca5a5;border-color:rgba(239,68,68,.4)}
.badge-k{background:rgba(156,163,175,.12);color:#d1d5db;border-color:rgba(156,163,175,.25)}
.badge-pm{background:rgba(239,68,68,.18);color:#fca5a5;border-color:rgba(239,68,68,.4)}
.badge-mid{background:rgba(245,158,11,.18);color:#fcd34d;border-color:rgba(245,158,11,.4)}
.badge-pn{background:rgba(34,197,94,.18);color:#86efac;border-color:rgba(34,197,94,.4)}

/* Info rows */
.ir{display:flex;justify-content:space-between;align-items:flex-start;font-size:12px;padding:7px 0;border-bottom:1px solid rgba(255,255,255,0.06)}
.ir:last-child{border-bottom:none}
.il{color:rgba(255,255,255,0.45)}
.iv{color:#e2e8f0;font-weight:500;text-align:right;max-width:65%}

/* Tables */
.ftable{width:100%;border-collapse:collapse;font-size:12px}
.ftable th{color:rgba(255,255,255,0.4);font-weight:500;padding:6px 8px;border-bottom:1px solid rgba(255,255,255,0.08);text-align:left}
.ftable th:not(:first-child){text-align:center}
.ftable td{padding:6px 8px;border-bottom:1px solid rgba(255,255,255,0.05);color:#e2e8f0}
.ftable td:not(:first-child){text-align:center}
.ftable tr:last-child td{border-bottom:none}
.ptag{display:inline-block;font-size:11px;padding:2px 8px;border-radius:4px;font-weight:500}
.ptag-ok{background:rgba(34,197,94,.2);color:#86efac;border:1px solid rgba(34,197,94,.3)}
.ptag-pend{background:rgba(245,158,11,.2);color:#fcd34d;border:1px solid rgba(245,158,11,.3)}
.ptag-na{background:rgba(255,255,255,.07);color:rgba(255,255,255,.4);border:1px solid rgba(255,255,255,.1)}

/* Section titles */
.stitle{font-size:10px;font-weight:600;color:rgba(255,255,255,.4);text-transform:uppercase;letter-spacing:.08em;margin:14px 0 8px}
.divider{height:1px;background:rgba(255,255,255,0.07);margin:14px 0}

/* Forms */
.lbl{font-size:11px;color:rgba(255,255,255,.5);display:block;margin-bottom:4px}
.finput{width:100%;padding:9px 11px;border:1px solid rgba(255,255,255,.18);border-radius:8px;background:rgba(255,255,255,.09);color:#fff;font-size:13px;font-family:inherit;margin-bottom:10px;outline:none;transition:border-color .2s}
.finput:focus{border-color:rgba(34,197,94,.5);background:rgba(255,255,255,.13)}
.finput::placeholder{color:rgba(255,255,255,.3)}
select.finput option{background:#0d2137;color:#fff}
textarea.finput{resize:vertical;min-height:70px}

/* Buttons */
.btn{width:100%;padding:10px;border-radius:8px;border:none;font-size:13px;font-weight:600;cursor:pointer;margin-bottom:8px;color:#fff;transition:opacity .15s,transform .15s}
.btn:hover{opacity:.88;transform:translateY(-1px)}
.btn-g{background:linear-gradient(-45deg,#064e3b,#065f46,#0f766e,#166534);background-size:300% 300%;animation:grad 4s ease infinite}
.btn-b{background:linear-gradient(-45deg,#1e3a5f,#1e40af,#1d4ed8,#2563eb);background-size:300% 300%;animation:grad 5s ease infinite}
.btn-r{background:linear-gradient(-45deg,#7f1d1d,#991b1b,#b91c1c,#c2410c);background-size:300% 300%;animation:grad 4s ease infinite}
.btn-sm{padding:6px 14px;width:auto;font-size:12px;margin-bottom:0;border-radius:6px}

/* Cards */
.fgroup{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-radius:10px;padding:11px;margin-bottom:8px}
.fgroup-title{font-size:12px;font-weight:600;color:#e2e8f0;margin-bottom:8px}
.fgrow{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.fgrow .finput{margin-bottom:0;font-size:12px;padding:7px 9px}

/* Reports */
.rcard{padding:10px;background:rgba(255,255,255,.06);border-radius:8px;margin-bottom:8px;border:1px solid rgba(255,255,255,.08);animation:fadeUp .3s ease}
.rcard p{font-size:12px;color:#e2e8f0;margin-bottom:4px}
.rcard span{font-size:10px;color:rgba(255,255,255,.4)}

/* Alerts */
.alert-blue{background:rgba(59,130,246,.14);border:1px solid rgba(59,130,246,.3);border-radius:8px;padding:10px 12px;font-size:12px;color:#93c5fd;margin-bottom:12px;line-height:1.6}
.alert-amber{background:rgba(245,158,11,.14);border:1px solid rgba(245,158,11,.3);border-radius:8px;padding:10px 12px;font-size:12px;color:#fcd34d;margin-bottom:12px;line-height:1.6}

/* Serial row */
.srow{display:flex;align-items:center;gap:6px;margin-bottom:12px;flex-wrap:wrap}

/* Toast */
#toast{position:fixed;bottom:80px;left:50%;transform:translateX(-50%);background:rgba(10,15,30,.96);border:1px solid rgba(255,255,255,.15);color:#fff;padding:10px 22px;border-radius:50px;font-size:13px;z-index:3000;opacity:0;pointer-events:none;transition:opacity .3s;white-space:nowrap;box-shadow:0 4px 20px rgba(0,0,0,.4)}
#toast.show{opacity:1}

/* Footer credit */
#credit{position:absolute;bottom:16px;right:16px;z-index:900;font-size:10px;color:rgba(255,255,255,.3)}
#credit a{color:rgba(255,255,255,.4);text-decoration:none}
#credit a:hover{color:#22c55e}

@media(max-width:599px){
  #topbar h1{font-size:12px}
  .legend{display:none}
  #fabs{gap:6px;bottom:12px}
  .fab{font-size:12px;padding:9px 14px}
}
</style>
</head>
<body>
<div id="app">
  <div id="map"></div>

  <div id="topbar">
    <div class="logo">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2.2"><path d="M3 22V9l9-7 9 7v13"/><path d="M14 22v-7H10v7"/><path d="M9 9h6v5H9z"/></svg>
      <h1>CTG <span>Fuel</span> Tracker</h1>
    </div>
    <span id="pump-count">লোড হচ্ছে...</span>
  </div>

  <div class="legend">
    <div class="leg"><div class="dot" style="background:#22c55e"></div>তেল আছে</div>
    <div class="leg"><div class="dot" style="background:#f59e0b"></div>সীমিত</div>
    <div class="leg"><div class="dot" style="background:#ef4444"></div>নেই</div>
    <div class="leg"><div class="dot" style="background:#9ca3af"></div>অজানা</div>
  </div>

  <div id="fabs">
    <button class="fab" onclick="userAddPump()">+ পাম্প যোগ করুন</button>
    <button class="fab fab-admin" onclick="window.location='/admin/'">⚙ Admin</button>
  </div>

  <div id="toast"></div>

  <div id="panel">
    <div class="ph">
      <div class="ph-title" id="ptitle">বিস্তারিত</div>
      <button class="ph-close" onclick="closePanel()">✕</button>
    </div>
    <div class="pb" id="pbody"></div>
  </div>

  <div id="credit">Developed by <a href="https://www.facebook.com/avrojit.ovi/" target="_blank">Avrojit Chowdhury Ovi</a></div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<script>
const SC={available:{l:"তেল আছে",c:"#22c55e",b:"badge-g"},limited:{l:"সীমিত",c:"#f59e0b",b:"badge-a"},unavailable:{l:"নেই",c:"#ef4444",b:"badge-r"},unknown:{l:"অজানা",c:"#9ca3af",b:"badge-k"}};
const SER={many:{l:"সিরিয়াল বেশি",b:"badge-pm"},mid:{l:"সিরিয়াল মাঝারি",b:"badge-mid"},none:{l:"সিরিয়াল নেই",b:"badge-pn"},unknown:{l:"সিরিয়াল অজানা",b:"badge-k"}};
const FT=["অকটেন","পেট্রোল","ডিজেল"];
let map, markers={}, selId=null;

function isMobile(){return window.innerWidth<600;}

function setupPanel(){
  const p=document.getElementById("panel");
  p.className=isMobile()?"mobile":"desktop";
}

function icon(status){
  const c=SC[status]?.c||"#9ca3af";
  return L.divIcon({className:"",html:`<div style="width:16px;height:16px;background:${c};border-radius:50%;border:2.5px solid white;box-shadow:0 2px 6px rgba(0,0,0,.5)"></div>`,iconSize:[16,16],iconAnchor:[8,8]});
}

function fuelColor(av){return av==="আছে"?"#22c55e":av==="সীমিত"?"#f59e0b":av==="নেই"?"#ef4444":"#9ca3af";}

async function loadStations(){
  const res=await fetch('/api/stations.php');
  const data=await res.json();
  if(!data.success)return;
  Object.values(markers).forEach(m=>map.removeLayer(m));markers={};
  data.stations.forEach(s=>{
    const m=L.marker([s.lat,s.lng],{icon:icon(s.status)}).addTo(map).on("click",()=>openStation(s.id));
    markers[s.id]=m;
  });
  document.getElementById("pump-count").textContent=`${data.stations.length}টি পাম্প`;
}

async function openStation(id){
  selId=id;
  document.getElementById("ptitle").textContent="লোড হচ্ছে...";
  document.getElementById("pbody").innerHTML=`<p style="text-align:center;color:rgba(255,255,255,.4);padding:30px 0">⏳</p>`;
  document.getElementById("panel").classList.add("open");

  const res=await fetch(`/api/stations.php?id=${id}`);
  const data=await res.json();
  if(!data.success){toast("ডেটা লোড ব্যর্থ হয়েছে।");return;}
  const s=data.station;
  const cfg=SC[s.status]||SC.unknown;
  const ser=SER[s.serial_status||"unknown"]||SER.unknown;

  const fuelsHtml=s.fuels.map(f=>{
    const av=f.availability||"—";
    const pr=f.price?`<span class="ptag ptag-ok">৳${parseFloat(f.price).toFixed(0)}/লি.</span>`:`<span class="ptag ptag-na">—</span>`;
    const pend=f.pending_price?` <span class="ptag ptag-pend" title="অনুমোদন বাকি">৳${f.pending_price} ⏳</span>`:"";
    return`<tr><td>${f.fuel_type}</td><td><span style="color:${fuelColor(av)};font-weight:500">${av}</span></td><td>${pr}${pend}</td></tr>`;
  }).join("");

  const repsHtml=s.reports.length?s.reports.map(r=>{
    const rc=SC[r.status]||SC.unknown;
    return`<div class="rcard"><p>${r.note||"কোনো মন্তব্য নেই"} <span style="float:right;color:${rc.c};font-weight:500">${rc.l}</span></p><span>${r.created_at}</span></div>`;
  }).join(""):`<p style="font-size:12px;color:rgba(255,255,255,.35);text-align:center;padding:12px 0">এখনো কোনো রিপোর্ট নেই।</p>`;

  document.getElementById("ptitle").innerHTML=s.name+(s.is_user_submitted?`<span style="font-size:10px;background:rgba(59,130,246,.2);color:#93c5fd;padding:2px 7px;border-radius:4px;margin-left:6px;border:1px solid rgba(59,130,246,.3)">ব্যবহারকারী</span>`:"");

  // Price suggest form
  const suggestRows=FT.map(f=>{
    const existing=s.pending_suggests&&s.pending_suggests.includes(f);
    return`<div class="fgroup" style="margin-bottom:8px">
      <div class="fgroup-title">${f}${existing?` <span style="font-size:10px;color:#fcd34d">⏳ অনুমোদন বাকি</span>`:""}</div>
      ${existing?`<p style="font-size:11px;color:rgba(255,255,255,.35)">সাজেশন জমা আছে।</p>`:`
      <div style="display:grid;grid-template-columns:1fr auto;gap:8px;align-items:end">
        <div><span class="lbl">নতুন দাম (৳/লি.)</span>
        <input type="number" class="finput" id="ps-${f.replace(/[^\w]/g,'_')}" placeholder="যেমন: 132" min="0" step="0.5" style="margin-bottom:0"/></div>
        <button class="btn btn-g btn-sm" onclick="submitPriceSuggest(${id},'${f}')">জমা</button>
      </div>`}
    </div>`;
  }).join("");

  document.getElementById("pbody").innerHTML=`
    <div class="srow">
      <span class="badge ${cfg.b}"><span style="width:7px;height:7px;border-radius:50%;background:${cfg.c};display:inline-block"></span>${cfg.l}</span>
      <span class="badge ${ser.b}"><span style="width:7px;height:7px;border-radius:50%;background:${ser.b.includes('pm')?'#ef4444':ser.b.includes('mid')?'#f59e0b':ser.b.includes('pn')?'#22c55e':'#9ca3af'};display:inline-block"></span>${ser.l}</span>
    </div>
    <div class="ir"><span class="il">ঠিকানা</span><span class="iv">${s.address||"—"}</span></div>
    <div class="ir"><span class="il">শেষ আপডেট</span><span class="iv">${s.last_updated}</span></div>
    <div class="stitle">জ্বালানির অবস্থা ও দাম</div>
    <table class="ftable"><thead><tr><th>জ্বালানি</th><th>অবস্থা</th><th>দাম</th></tr></thead><tbody>${fuelsHtml}</tbody></table>
    <div class="divider"></div>
    <div class="stitle">দামের সাজেশন দিন</div>
    <div class="alert-amber">সাজেশন করা দাম Admin অনুমোদনের পর সবার জন্য দেখা যাবে।</div>
    ${suggestRows}
    <div class="divider"></div>
    <div class="stitle">রিপোর্ট করুন</div>
    <span class="lbl">তেলের অবস্থা</span>
    <select id="r-st" class="finput">
      ${Object.entries(SC).map(([k,v])=>`<option value="${k}">${v.l}</option>`).join("")}
    </select>
    <span class="lbl">সিরিয়াল অবস্থা</span>
    <select id="r-ser" class="finput">
      <option value="none">সিরিয়াল নেই</option>
      <option value="mid">সিরিয়াল মাঝারি</option>
      <option value="many">সিরিয়াল বেশি</option>
      <option value="unknown">অজানা</option>
    </select>
    <span class="lbl">মন্তব্য (ঐচ্ছিক)</span>
    <textarea id="r-note" class="finput" rows="2" placeholder="আপনার অভিজ্ঞতা লিখুন..."></textarea>
    <button class="btn btn-g" onclick="submitReport(${id})">রিপোর্ট জমা দিন</button>
    <div class="stitle">সাম্প্রতিক রিপোর্ট</div>
    ${repsHtml}
  `;
}

async function submitPriceSuggest(sid,fuel){
  const key='ps-'+fuel.replace(/[^\w]/g,'_');
  const inp=document.getElementById(key);
  if(!inp||!inp.value.trim()){toast("সঠিক দাম লিখুন!");return;}
  const res=await fetch('/api/suggest_price.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({station_id:sid,fuel_type:fuel,price:inp.value.trim()})});
  const data=await res.json();
  if(data.success){toast(`${fuel} দামের সাজেশন জমা হয়েছে! অনুমোদনের অপেক্ষায়।`);openStation(sid);}
  else toast(data.error||"সমস্যা হয়েছে।");
}

async function submitReport(sid){
  const status=document.getElementById("r-st").value;
  const serial=document.getElementById("r-ser").value;
  const note=document.getElementById("r-note").value.trim();
  const res=await fetch('/api/report.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({station_id:sid,status,serial_status:serial,note})});
  const data=await res.json();
  if(data.success){toast("রিপোর্ট জমা হয়েছে! ধন্যবাদ।");loadStations();openStation(sid);}
  else toast(data.error||"সমস্যা হয়েছে।");
}

function userAddPump(){
  document.getElementById("ptitle").textContent="অবস্থান খোঁজা হচ্ছে...";
  document.getElementById("pbody").innerHTML=`<p style="text-align:center;color:rgba(255,255,255,.4);padding:30px 0;font-size:13px">📍 Location অ্যাক্সেস করা হচ্ছে...</p>`;
  document.getElementById("panel").classList.add("open");
  if(!navigator.geolocation){showAddForm(null,null,true);return;}
  navigator.geolocation.getCurrentPosition(
    pos=>{map.flyTo([pos.coords.latitude,pos.coords.longitude],16,{duration:1.2});showAddForm(pos.coords.latitude,pos.coords.longitude,false);},
    ()=>showAddForm(null,null,true)
  );
}

function showAddForm(lat,lng,manual){
  const FT=["অকটেন","পেট্রোল","ডিজেল"];
  document.getElementById("ptitle").textContent="নতুন পাম্প যোগ করুন";
  document.getElementById("pbody").innerHTML=`
    ${lat?`<div class="alert-blue">📍 বর্তমান অবস্থান ব্যবহার করা হচ্ছে।<br><small>${lat.toFixed(5)}, ${lng.toFixed(5)}</small></div>`:
    `<div class="alert-blue">Location অনুমতি পাওয়া যায়নি। ম্যানুয়ালি দিন।</div>
    <span class="lbl">Latitude</span><input type="number" class="finput" id="u-lat" placeholder="22.3569" step="0.00001"/>
    <span class="lbl">Longitude</span><input type="number" class="finput" id="u-lng" placeholder="91.7832" step="0.00001"/>`}
    <span class="lbl">পাম্পের নাম *</span><input type="text" class="finput" id="u-name" placeholder="যেমন: রহিম ফিলিং স্টেশন"/>
    <span class="lbl">ঠিকানা</span><input type="text" class="finput" id="u-addr" placeholder="যেমন: কদমতলী, চট্টগ্রাম"/>
    <span class="lbl">সার্বিক অবস্থা</span>
    <select id="u-status" class="finput">${Object.entries(SC).map(([k,v])=>`<option value="${k}">${v.l}</option>`).join("")}</select>
    <span class="lbl">সিরিয়াল অবস্থা</span>
    <select id="u-ser" class="finput"><option value="none">সিরিয়াল নেই</option><option value="mid">সিরিয়াল মাঝারি</option><option value="many">সিরিয়াল বেশি</option><option value="unknown">অজানা</option></select>
    <div class="stitle">জ্বালানির অবস্থা ও দাম</div>
    ${FT.map(f=>`<div class="fgroup"><div class="fgroup-title">${f}</div><div class="fgrow">
      <div><span class="lbl">অবস্থা</span><select id="us-${f.replace(/[^\w]/g,'_')}" class="finput"><option value="আছে">আছে</option><option value="সীমিত">সীমিত</option><option value="নেই">নেই</option><option value="প্রযোজ্য নয়">N/A</option></select></div>
      <div><span class="lbl">দাম (৳)</span><input type="number" class="finput" id="up-${f.replace(/[^\w]/g,'_')}" placeholder="যেমন: 130"/></div>
    </div></div>`).join("")}
    <button class="btn btn-g" onclick="submitUserStation(${lat||'null'},${lng||'null'})">পাম্প যোগ করুন</button>
    <button class="btn btn-b" onclick="closePanel()">বাতিল</button>
  `;
}

async function submitUserStation(lat,lng){
  const name=document.getElementById("u-name").value.trim();
  if(!name){toast("পাম্পের নাম দিন!");return;}
  let la=lat,ln=lng;
  if(!la){la=parseFloat(document.getElementById("u-lat").value);ln=parseFloat(document.getElementById("u-lng").value);if(isNaN(la)||isNaN(ln)){toast("সঠিক অবস্থান দিন!");return;}}
  const FT=["অকটেন","পেট্রোল","ডিজেল"];
  const fuels=FT.map(f=>({fuel_type:f,availability:document.getElementById(`us-${f.replace(/[^\w]/g,'_')}`).value,price:document.getElementById(`up-${f.replace(/[^\w]/g,'_')}`).value||null}));
  const body={name,address:document.getElementById("u-addr").value.trim(),lat:la,lng:ln,status:document.getElementById("u-status").value,serial_status:document.getElementById("u-ser").value,fuels,is_user_submitted:1};
  const res=await fetch('/api/add_station.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const data=await res.json();
  if(data.success){toast(`"${name}" যোগ করা হয়েছে!`);closePanel();loadStations();}
  else toast(data.error||"সমস্যা হয়েছে।");
}

function closePanel(){document.getElementById("panel").classList.remove("open");selId=null;}

function toast(msg,dur=3500){
  const t=document.getElementById("toast");
  t.textContent=msg;t.classList.add("show");
  setTimeout(()=>t.classList.remove("show"),dur);
}

window.addEventListener('resize',()=>{setupPanel();map&&map.invalidateSize();});

async function init(){
  setupPanel();
  map=L.map("map",{zoomControl:true}).setView([22.3569,91.7832],13);
  L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png",{
    attribution:'© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> © <a href="https://carto.com/">CARTO</a>',
    subdomains:"abcd",maxZoom:19
  }).addTo(map);
  await loadStations();
}
init();
</script>
</body>
</html>
