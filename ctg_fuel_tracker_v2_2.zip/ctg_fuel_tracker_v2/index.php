<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>CTG Fuel Tracker</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css"/>
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
:root{--or:#f97316;--gr:#22c55e;--rd:#ef4444;--am:#f59e0b;--gy:#6b7280;--dk:#0f1117;--dk2:#1a1f2e;--dk3:#252b3b;--bd:rgba(255,255,255,0.08)}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
@keyframes fadeIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
html,body{height:100%;overflow:hidden;font-family:'Segoe UI',system-ui,-apple-system,sans-serif;background:var(--dk);color:#fff}
#app{position:fixed;inset:0;display:flex;flex-direction:column}

/* Header */
#hdr{background:var(--dk2);border-bottom:1px solid var(--bd);flex-shrink:0;z-index:1000}
#hdr-top{display:flex;align-items:center;justify-content:space-between;padding:10px 14px}
.logo{display:flex;align-items:center;gap:9px}
.logo-ic{width:34px;height:34px;background:var(--or);border-radius:9px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.logo-tx h1{font-size:16px;font-weight:700;color:#fff;line-height:1.1}
.logo-tx p{font-size:9px;color:rgba(255,255,255,.4);margin-top:1px}
.hdr-r{display:flex;align-items:center;gap:7px}
.live-b{display:flex;align-items:center;gap:5px;background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.22);border-radius:20px;padding:5px 11px;font-size:12px;color:var(--gr);font-weight:500;white-space:nowrap}
.live-dot{width:7px;height:7px;background:var(--gr);border-radius:50%;animation:pulse 2s infinite}
.rep-btn{display:flex;align-items:center;gap:5px;background:var(--or);border:none;border-radius:20px;padding:8px 13px;font-size:12px;font-weight:700;color:#fff;cursor:pointer;white-space:nowrap;touch-action:manipulation}
.rep-btn:active{opacity:.82}

/* Stats */
#stats{display:grid;grid-template-columns:repeat(4,1fr);border-top:1px solid var(--bd)}
.si{padding:7px 10px;display:flex;align-items:center;gap:7px;border-right:1px solid var(--bd)}
.si:last-child{border-right:none}
.si-v{font-size:14px;font-weight:700;color:#fff;line-height:1}
.si-l{font-size:9px;color:rgba(255,255,255,.35);margin-top:2px}
.si-ico{font-size:14px;flex-shrink:0}

/* Map */
#mapw{flex:1;position:relative;min-height:0}
#map{width:100%;height:100%}
.map-leg{position:absolute;top:10px;right:10px;z-index:900;background:rgba(15,17,23,.9);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);border:1px solid var(--bd);border-radius:10px;padding:9px 12px}
.ml{display:flex;align-items:center;gap:6px;font-size:11px;color:rgba(255,255,255,.7);margin-bottom:5px}
.ml:last-child{margin-bottom:0}
.mldot{width:9px;height:9px;border-radius:50%;flex-shrink:0}

/* Bottom Sheet */
#bs{background:var(--dk2);border-top:1px solid var(--bd);flex-shrink:0;display:flex;flex-direction:column;transition:height .3s cubic-bezier(.4,0,.2,1);overflow:hidden}
#bs.col{height:56px}
#bs.exp{height:55vh}
@media(min-width:700px){#bs.exp{height:42vh}}
.bs-hr{padding:0 14px;height:56px;display:flex;align-items:center;justify-content:space-between;cursor:pointer;flex-shrink:0;user-select:none}
.bs-ttl{display:flex;align-items:center;gap:7px}
.bs-ttl h3{font-size:13px;font-weight:600;color:#fff}
.bs-rdot{width:7px;height:7px;background:var(--rd);border-radius:50%;animation:pulse 1.5s infinite}
.bs-sub{font-size:9px;color:rgba(255,255,255,.3);margin-top:1px}
.bs-arr{color:rgba(255,255,255,.35);font-size:16px;transition:transform .3s}
#bs.exp .bs-arr{transform:rotate(180deg)}
.bs-ctrl{padding:0 12px 10px;flex-shrink:0}
.srch-w{position:relative;margin-bottom:8px}
.srch-i{width:100%;background:var(--dk3);border:1px solid var(--bd);border-radius:10px;padding:9px 12px 9px 34px;color:#fff;font-size:13px;outline:none;-webkit-appearance:none}
.srch-i::placeholder{color:rgba(255,255,255,.3)}
.srch-ic{position:absolute;left:11px;top:50%;transform:translateY(-50%);color:rgba(255,255,255,.3)}
.ftabs{display:flex;gap:6px;overflow-x:auto;padding-bottom:2px;scrollbar-width:none}
.ftabs::-webkit-scrollbar{display:none}
.ftab{padding:6px 13px;border-radius:20px;border:1px solid var(--bd);background:var(--dk3);color:rgba(255,255,255,.55);font-size:12px;font-weight:500;white-space:nowrap;cursor:pointer;flex-shrink:0;touch-action:manipulation}
.ftab.on{background:var(--or);border-color:var(--or);color:#fff}
.ftab:active{opacity:.8}
#feed{overflow-y:auto;-webkit-overflow-scrolling:touch;flex:1}
.rc{padding:11px 14px;border-bottom:1px solid var(--bd);display:flex;gap:11px;align-items:flex-start;animation:fadeIn .2s ease}
.rc-ic{width:42px;height:42px;border-radius:10px;background:var(--dk3);flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:20px}
.rc-bd{flex:1;min-width:0}
.rc-nm{font-size:13px;font-weight:600;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rc-mt{font-size:10px;color:rgba(255,255,255,.35);margin-top:2px}
.rc-mt span{color:var(--or)}
.rc-nt{font-size:11px;color:rgba(255,255,255,.45);margin-top:4px;line-height:1.4;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.rc-ac{display:flex;gap:5px;margin-top:8px;flex-wrap:wrap}
.rbtn{display:inline-flex;align-items:center;gap:3px;padding:4px 9px;border-radius:16px;border:1px solid var(--bd);background:var(--dk3);color:rgba(255,255,255,.55);font-size:11px;cursor:pointer;white-space:nowrap;touch-action:manipulation}
.rbtn:active{opacity:.7}
.rbtn.map{border-color:var(--or);color:var(--or);background:rgba(249,115,22,.1)}
.rc-rt{display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex-shrink:0}
.chip{padding:3px 8px;border-radius:6px;font-size:10px;font-weight:600;white-space:nowrap}
.cg{background:rgba(34,197,94,.14);color:var(--gr);border:1px solid rgba(34,197,94,.28)}
.ca{background:rgba(245,158,11,.14);color:var(--am);border:1px solid rgba(245,158,11,.28)}
.cr{background:rgba(239,68,68,.14);color:var(--rd);border:1px solid rgba(239,68,68,.28)}
.ck{background:rgba(107,114,128,.12);color:var(--gy);border:1px solid rgba(107,114,128,.22)}
.priceb{font-size:14px;font-weight:700;color:#fff}
.pricel{font-size:9px;color:rgba(255,255,255,.35)}
.empty{text-align:center;padding:40px;color:rgba(255,255,255,.3);font-size:13px}

/* Detail Panel */
#dp{position:fixed;inset:0;z-index:2000;background:var(--dk2);transform:translateY(100%);transition:transform .3s cubic-bezier(.4,0,.2,1);display:flex;flex-direction:column}
#dp.open{transform:translateY(0)}
.dp-hdr{padding:12px 14px;border-bottom:1px solid var(--bd);display:flex;align-items:center;gap:10px;flex-shrink:0}
.dp-bk{background:var(--dk3);border:none;border-radius:8px;width:32px;height:32px;display:flex;align-items:center;justify-content:center;cursor:pointer;color:rgba(255,255,255,.7);font-size:17px;flex-shrink:0;touch-action:manipulation}
.dp-ttl{font-size:14px;font-weight:600;color:#fff;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dp-repbtn{background:var(--or);border:none;border-radius:18px;padding:7px 13px;font-size:12px;font-weight:700;color:#fff;cursor:pointer;flex-shrink:0;touch-action:manipulation}
.dp-body{overflow-y:auto;-webkit-overflow-scrolling:touch;flex:1;padding:14px}
.dp-stl{font-size:10px;font-weight:600;color:rgba(255,255,255,.35);text-transform:uppercase;letter-spacing:.08em;margin:14px 0 8px}
.dp-row{display:flex;justify-content:space-between;align-items:flex-start;font-size:13px;padding:7px 0;border-bottom:1px solid var(--bd)}
.dp-row:last-child{border-bottom:none}
.dp-l{color:rgba(255,255,255,.4)}
.dp-v{color:#e2e8f0;font-weight:500;text-align:right;max-width:65%}
.fg{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:10px}
.fc{background:var(--dk3);border:1px solid var(--bd);border-radius:10px;padding:11px 8px;text-align:center}
.fc-n{font-size:10px;color:rgba(255,255,255,.4);margin-bottom:5px}
.fc-s{font-size:12px;font-weight:600;margin-bottom:4px}
.fc-p{font-size:13px;font-weight:700;color:var(--or)}
.sg-row{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:end;margin-bottom:8px}
.dp-inp{width:100%;background:var(--dk3);border:1px solid var(--bd);border-radius:8px;padding:10px 11px;color:#fff;font-size:13px;outline:none;-webkit-appearance:none;font-family:inherit}
.dp-inp:focus{border-color:var(--or)}
.dp-inp::placeholder{color:rgba(255,255,255,.28)}
select.dp-inp option{background:var(--dk2)}
.dp-btn{padding:10px 14px;border-radius:8px;border:none;font-size:12px;font-weight:600;cursor:pointer;color:#fff;touch-action:manipulation;min-height:40px;display:flex;align-items:center;justify-content:center}
.dp-or{background:var(--or)}
.dp-dk{background:var(--dk3);border:1px solid var(--bd);color:rgba(255,255,255,.55)}
.dp-btn:active{opacity:.8}
.dp-btn-w{width:100%;margin-bottom:8px;min-height:46px;font-size:13px}
.rmin{background:var(--dk3);border-radius:8px;padding:10px 11px;margin-bottom:7px;border:1px solid var(--bd)}
.rmin p{font-size:12px;color:#e2e8f0;margin-bottom:3px}
.rmin time{font-size:10px;color:rgba(255,255,255,.35)}
.ptag{font-size:10px;background:rgba(245,158,11,.15);color:var(--am);border:1px solid rgba(245,158,11,.28);padding:2px 7px;border-radius:4px}

/* Report Modal */
#rm{position:fixed;inset:0;z-index:3000;background:rgba(0,0,0,.6);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px);display:flex;align-items:flex-end;opacity:0;pointer-events:none;transition:opacity .25s}
#rm.open{opacity:1;pointer-events:all}
.rm-sh{background:var(--dk2);border-radius:18px 18px 0 0;border-top:1px solid var(--bd);width:100%;padding:18px 14px calc(18px + env(safe-area-inset-bottom,0px));transform:translateY(32px);transition:transform .28s;max-height:90vh;overflow-y:auto}
#rm.open .rm-sh{transform:translateY(0)}
.rm-hd{font-size:15px;font-weight:700;color:#fff;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between}
.rm-cl{background:var(--dk3);border:none;border-radius:7px;width:28px;height:28px;color:rgba(255,255,255,.55);font-size:15px;cursor:pointer;display:flex;align-items:center;justify-content:center}
.rm-lbl{font-size:11px;color:rgba(255,255,255,.45);display:block;margin-bottom:5px;font-weight:500}
.rm-inp{width:100%;background:var(--dk3);border:1px solid var(--bd);border-radius:8px;padding:10px 11px;color:#fff;font-size:13px;outline:none;margin-bottom:10px;-webkit-appearance:none;font-family:inherit}
.rm-inp::placeholder{color:rgba(255,255,255,.28)}
.og{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-bottom:12px}
.oo{padding:9px 8px;border-radius:8px;border:1px solid var(--bd);background:var(--dk3);color:rgba(255,255,255,.55);font-size:12px;font-weight:500;cursor:pointer;text-align:center;touch-action:manipulation}
.oo.on{border-color:var(--or);color:var(--or);background:rgba(249,115,22,.1)}
.oo:active{opacity:.75}
.rm-sub{width:100%;padding:13px;background:var(--or);border:none;border-radius:10px;color:#fff;font-size:14px;font-weight:700;cursor:pointer;touch-action:manipulation;min-height:48px}
.rm-sub:active{opacity:.85}
.sres{background:var(--dk3);border:1px solid var(--bd);border-radius:8px;margin-bottom:10px;max-height:150px;overflow-y:auto}
.sres-it{padding:9px 12px;border-bottom:1px solid var(--bd);cursor:pointer}
.sres-it:last-child{border-bottom:none}
.sres-it:active{background:var(--dk2)}
.sres-it h4{font-size:13px;color:#fff}
.sres-it p{font-size:10px;color:rgba(255,255,255,.35);margin-top:2px}
.sel-st{background:rgba(249,115,22,.1);border:1px solid rgba(249,115,22,.28);border-radius:8px;padding:9px 12px;font-size:13px;color:var(--or);margin-bottom:10px}

/* Toast */
#toast{position:fixed;bottom:calc(68px + env(safe-area-inset-bottom,0px));left:50%;transform:translateX(-50%);background:rgba(10,12,20,.96);border:1px solid rgba(255,255,255,.12);color:#fff;padding:10px 20px;border-radius:50px;font-size:13px;z-index:5000;opacity:0;pointer-events:none;transition:opacity .3s;max-width:calc(100vw - 28px);text-align:center;white-space:nowrap}
#toast.show{opacity:1}
.leaflet-top,.leaflet-bottom{z-index:800!important}
.leaflet-control-attribution{font-size:9px!important}
</style>
</head>
<body>
<div id="app">
  <div id="hdr">
    <div id="hdr-top">
      <div class="logo">
        <div class="logo-ic">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><path d="M3 22V9l9-7 9 7v13"/><path d="M14 22v-7H10v7"/><path d="M9 9h6v5H9z"/></svg>
        </div>
        <div class="logo-tx">
          <h1>CTG Fuel Tracker</h1>
          <p>by Avrojit Chowdhury Ovi</p>
        </div>
      </div>
      <div class="hdr-r">
        <div class="live-b"><div class="live-dot"></div>Live: <span id="lc">0</span></div>
        <button class="rep-btn" onclick="openRM()">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          রিপোর্ট দিন
        </button>
      </div>
    </div>
    <div id="stats">
      <div class="si"><span class="si-ico">⛽</span><div><div class="si-v" id="ss">—</div><div class="si-l">স্টেশন</div></div></div>
      <div class="si"><span class="si-ico">📋</span><div><div class="si-v" id="sr">—</div><div class="si-l">রিপোর্ট</div></div></div>
      <div class="si"><span class="si-ico">👥</span><div><div class="si-v" id="su">—</div><div class="si-l">ব্যবহারকারী</div></div></div>
      <div class="si"><span class="si-ico">📈</span><div><div class="si-v" id="sp">—</div><div class="si-l">গড় অকটেন</div></div></div>
    </div>
  </div>

  <div id="mapw">
    <div id="map"></div>
    <div class="map-leg">
      <div class="ml"><div class="mldot" style="background:var(--gr)"></div>লাইন নেই</div>
      <div class="ml"><div class="mldot" style="background:var(--am)"></div>অল্প লাইন</div>
      <div class="ml"><div class="mldot" style="background:var(--rd)"></div>অনেক লাইন</div>
      <div class="ml"><div class="mldot" style="background:var(--gy)"></div>তেল দিচ্ছে না</div>
    </div>
  </div>

  <div id="bs" class="col">
    <div class="bs-hr" onclick="toggleBS()">
      <div>
        <div class="bs-ttl"><div class="bs-rdot"></div><h3>সাম্প্রতিক রিপোর্টসমূহ</h3></div>
        <div class="bs-sub">ছবি দেখতে ছবিতে চেপে ধরুন</div>
      </div>
      <div class="bs-arr">⌃</div>
    </div>
    <div class="bs-ctrl">
      <div class="srch-w">
        <span class="srch-ic">🔍</span>
        <input type="text" class="srch-i" id="si" placeholder="স্টেশনের নাম দিয়ে খুঁজুন..." oninput="renderFeed()"/>
      </div>
      <div class="ftabs" id="ftabs">
        <div class="ftab on" onclick="setF('all',this)">সব</div>
        <div class="ftab" onclick="setF('none',this)">লাইন নেই</div>
        <div class="ftab" onclick="setF('mid',this)">লাইন অল্প</div>
        <div class="ftab" onclick="setF('many',this)">লাইন অনেক</div>
        <div class="ftab" onclick="setF('unavailable',this)">দিচ্ছে না</div>
      </div>
    </div>
    <div id="feed"></div>
  </div>
</div>

<!-- Detail Panel -->
<div id="dp">
  <div class="dp-hdr">
    <button class="dp-bk" onclick="closeDP()">←</button>
    <div class="dp-ttl" id="dp-ttl">স্টেশন</div>
    <button class="dp-repbtn" onclick="openRM(curSid)">রিপোর্ট</button>
  </div>
  <div class="dp-body" id="dp-body"></div>
</div>

<!-- Report Modal -->
<div id="rm" onclick="if(event.target===this)closeRM()">
  <div class="rm-sh" onclick="event.stopPropagation()">
    <div class="rm-hd">রিপোর্ট দিন <button class="rm-cl" onclick="closeRM()">✕</button></div>
    <span class="rm-lbl">স্টেশন বেছে নিন *</span>
    <input type="text" class="rm-inp" id="rms" placeholder="স্টেশনের নাম লিখুন..." oninput="rmSearch()"/>
    <div id="rm-res" class="sres" style="display:none"></div>
    <div id="rm-sel" class="sel-st" style="display:none"></div>
    <span class="rm-lbl">তেলের অবস্থা</span>
    <div class="og" id="og-st">
      <div class="oo on" data-v="available" onclick="selO(this,'og-st')">✅ তেল আছে</div>
      <div class="oo" data-v="limited" onclick="selO(this,'og-st')">🟡 সীমিত</div>
      <div class="oo" data-v="unavailable" onclick="selO(this,'og-st')">❌ নেই</div>
      <div class="oo" data-v="unknown" onclick="selO(this,'og-st')">❓ অজানা</div>
    </div>
    <span class="rm-lbl">লাইনের অবস্থা</span>
    <div class="og" id="og-ser">
      <div class="oo on" data-v="none" onclick="selO(this,'og-ser')">😊 লাইন নেই</div>
      <div class="oo" data-v="mid" onclick="selO(this,'og-ser')">🟡 অল্প লাইন</div>
      <div class="oo" data-v="many" onclick="selO(this,'og-ser')">😰 অনেক লাইন</div>
      <div class="oo" data-v="unknown" onclick="selO(this,'og-ser')">❓ জানি না</div>
    </div>
    <span class="rm-lbl">মন্তব্য (ঐচ্ছিক)</span>
    <textarea class="rm-inp" id="rm-nt" rows="2" placeholder="আপনার অভিজ্ঞতা লিখুন..."></textarea>
    <button class="rm-sub" onclick="submitRep()">রিপোর্ট জমা দিন →</button>
  </div>
</div>

<div id="toast"></div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<script>
let map,markers={},allSt=[],allRep=[],curF='all',curSid=null,rmSid=null,toastT;

const SC={available:'তেল আছে',limited:'সীমিত',unavailable:'দিচ্ছে না',unknown:'অজানা'};
const SER={none:'😊 লাইন নেই',mid:'🟡 অল্প লাইন',many:'😰 অনেক লাইন',unknown:'❓ অজানা'};
const CC={available:'cg',limited:'ca',unavailable:'cr',unknown:'ck'};
const CS={none:'cg',mid:'ca',many:'cr',unknown:'ck'};
const FC={available:'#22c55e',limited:'#f59e0b',unavailable:'#ef4444',unknown:'#6b7280'};

// Map init
function initMap(){
  map=L.map('map',{zoomControl:false}).setView([22.3569,91.7832],13);
  L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',{
    attribution:'© <a href="https://openstreetmap.org">OSM</a> © <a href="https://carto.com">CARTO</a>',
    subdomains:'abcd',maxZoom:19
  }).addTo(map);
  L.control.zoom({position:'topright'}).addTo(map);
}

// Pump pin icon
function mkIcon(status){
  const c=FC[status]||'#6b7280';
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="32" height="42" viewBox="0 0 32 42">
    <defs><filter id="s" x="-30%" y="-20%" width="160%" height="160%"><feDropShadow dx="0" dy="2" stdDeviation="2" flood-color="rgba(0,0,0,0.6)"/></filter></defs>
    <path d="M16 1C8.8 1 3 6.8 3 14c0 9.5 13 27 13 27S29 23.5 29 14C29 6.8 23.2 1 16 1z" fill="${c}" filter="url(#s)"/>
    <circle cx="16" cy="14" r="7.5" fill="rgba(255,255,255,0.2)"/>
    <text x="16" y="18" text-anchor="middle" font-size="9" fill="white" font-weight="bold" font-family="system-ui">⛽</text>
  </svg>`;
  return L.divIcon({className:'',html:svg,iconSize:[32,42],iconAnchor:[16,42]});
}

function fc(av){return av==='আছে'?'#22c55e':av==='সীমিত'?'#f59e0b':av==='নেই'?'#ef4444':'#6b7280';}
function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}

// Load stations
async function loadSt(){
  try{
    const r=await fetch('/api/stations.php');const d=await r.json();
    if(!d.success)return;allSt=d.stations;
    document.getElementById('ss').textContent=d.stations.length;
    document.getElementById('lc').textContent=d.stations.length;
    Object.values(markers).forEach(m=>map.removeLayer(m));markers={};
    d.stations.forEach(s=>{
      const m=L.marker([s.lat,s.lng],{icon:mkIcon(s.status)}).addTo(map).on('click',()=>openDP(s.id));
      markers[s.id]=m;
    });
  }catch(e){}
}

// Load reports
async function loadRep(){
  try{
    const r=await fetch('/api/reports.php');const d=await r.json();
    if(!d.success)return;allRep=d.reports;
    document.getElementById('sr').textContent=d.total||d.reports.length;
    document.getElementById('su').textContent=d.unique_users||'—';
    document.getElementById('sp').textContent=d.avg_price?'৳'+d.avg_price:'—';
    renderFeed();
  }catch(e){}
}

// Render feed
function renderFeed(){
  const q=document.getElementById('si').value.toLowerCase();
  let list=allRep.filter(r=>{
    if(curF==='unavailable'&&r.status!=='unavailable')return false;
    if(curF!=='all'&&curF!=='unavailable'&&r.serial_status!==curF)return false;
    if(q&&!r.station_name.toLowerCase().includes(q))return false;
    return true;
  });
  const feed=document.getElementById('feed');
  if(!list.length){feed.innerHTML=`<div class="empty">কোনো রিপোর্ট নেই।</div>`;return;}
  feed.innerHTML=list.slice(0,60).map(r=>`
    <div class="rc">
      <div class="rc-ic">⛽</div>
      <div class="rc-bd">
        <div class="rc-nm">${esc(r.station_name)}</div>
        <div class="rc-mt">${esc(r.time_ago||r.created_at)} · সহায়তায়: <span>${esc(r.reporter||'user')}</span></div>
        ${r.note?`<div class="rc-nt">${esc(r.note)}</div>`:''}
        <div class="rc-ac">
          <div class="rbtn">👍 সঠিক (${r.upvotes||0})</div>
          <div class="rbtn">👎 ভুল (${r.downvotes||0})</div>
          <div class="rbtn map" onclick="goSt(${r.station_id})">📍 ম্যাপ</div>
        </div>
      </div>
      <div class="rc-rt">
        <div class="chip ${CC[r.status]||'ck'}">${SC[r.status]||'অজানা'}</div>
        <div class="chip ${CS[r.serial_status]||'ck'}" style="font-size:9px">${SER[r.serial_status]||'অজানা'}</div>
        ${r.price?`<div class="priceb">৳${r.price}</div><div class="pricel">অকটেন</div>`:''}
      </div>
    </div>`).join('');
}

function setF(f,el){curF=f;document.querySelectorAll('.ftab').forEach(t=>t.classList.remove('on'));el.classList.add('on');renderFeed();}
function goSt(sid){const s=allSt.find(x=>x.id==sid);if(s){map.flyTo([s.lat,s.lng],16,{duration:1});document.getElementById('bs').classList.replace('exp','col');}}

// Detail Panel
async function openDP(id){
  curSid=id;
  document.getElementById('dp-ttl').textContent='লোড হচ্ছে...';
  document.getElementById('dp-body').innerHTML=`<div style="text-align:center;padding:50px;font-size:22px">⏳</div>`;
  document.getElementById('dp').classList.add('open');
  const r=await fetch('/api/stations.php?id='+id);const d=await r.json();
  if(!d.success){toast('লোড ব্যর্থ।');return;}
  const s=d.station;
  document.getElementById('dp-ttl').textContent=s.name;
  const S2={available:'✅ তেল আছে',limited:'🟡 সীমিত',unavailable:'❌ দিচ্ছে না',unknown:'❓ অজানা'};
  const SE2={none:'😊 লাইন নেই',mid:'🟡 অল্প লাইন',many:'😰 অনেক লাইন',unknown:'❓ অজানা'};
  const fcds=s.fuels.map(f=>`<div class="fc"><div class="fc-n">${f.fuel_type}</div><div class="fc-s" style="color:${fc(f.availability||'')}">${f.availability||'—'}</div><div class="fc-p">${f.price?'৳'+parseFloat(f.price).toFixed(0):'—'}</div></div>`).join('');
  const sugg=(['অকটেন','পেট্রোল','ডিজেল']).map(f=>{
    const k='ps_'+f.replace(/[^\w]/g,'_');
    const ex=s.pending_suggests&&s.pending_suggests.includes(f);
    return`<div style="background:var(--dk3);border:1px solid var(--bd);border-radius:8px;padding:10px;margin-bottom:8px">
      <div style="font-size:12px;font-weight:600;color:#e2e8f0;margin-bottom:7px">${f}${ex?` <span class="ptag">⏳ বাকি</span>`:''}</div>
      ${ex?`<p style="font-size:11px;color:rgba(255,255,255,.35)">সাজেশন জমা আছে।</p>`:`
      <div class="sg-row"><div>
        <div style="font-size:10px;color:rgba(255,255,255,.35);margin-bottom:4px">নতুন দাম (৳/লি.)</div>
        <input type="number" class="dp-inp" id="${k}" placeholder="132" min="0" step="0.5" inputmode="decimal"/>
      </div><button class="dp-btn dp-or" onclick="subPS(${id},'${f}','${k}')" style="min-height:38px;padding:0 13px;font-size:12px">জমা</button></div>`}
    </div>`;
  }).join('');
  const reps=s.reports&&s.reports.length?s.reports.map(r=>`<div class="rmin"><p>${esc(r.note||'কোনো মন্তব্য নেই')} <span style="float:right;font-size:10px;color:${r.status==='available'?'#22c55e':r.status==='unavailable'?'#ef4444':'#f59e0b'}">${SC[r.status]||''}</span></p><time>${r.created_at}</time></div>`).join(''):`<p style="font-size:12px;color:rgba(255,255,255,.3);text-align:center;padding:12px">রিপোর্ট নেই।</p>`;
  document.getElementById('dp-body').innerHTML=`
    <div style="display:flex;gap:7px;flex-wrap:wrap;margin-bottom:12px">
      <span class="chip ${CC[s.status]||'ck'}">${S2[s.status]||'অজানা'}</span>
      <span class="chip ${CS[s.serial_status]||'ck'}">${SE2[s.serial_status]||'অজানা'}</span>
    </div>
    <div class="dp-row"><span class="dp-l">ঠিকানা</span><span class="dp-v">${esc(s.address||'—')}</span></div>
    <div class="dp-row"><span class="dp-l">শেষ আপডেট</span><span class="dp-v">${s.last_updated||'—'}</span></div>
    <div class="dp-stl">জ্বালানির অবস্থা</div>
    <div class="fg">${fcds}</div>
    <div class="dp-stl">দামের সাজেশন দিন</div>
    <div style="background:rgba(245,158,11,.1);border:1px solid rgba(245,158,11,.22);border-radius:8px;padding:9px 11px;font-size:12px;color:var(--am);margin-bottom:10px">Admin অনুমোদনের পর দেখা যাবে।</div>
    ${sugg}
    <div class="dp-stl">সাম্প্রতিক রিপোর্ট</div>${reps}
    ${s.is_user_submitted?'<div style="text-align:center;font-size:10px;color:rgba(255,255,255,.2);margin-top:8px">📍 ব্যবহারকারী কর্তৃক যোগকৃত</div>':''}`;
}
function closeDP(){document.getElementById('dp').classList.remove('open');curSid=null;}

// Price suggest
async function subPS(sid,fuel,key){
  const inp=document.getElementById(key);if(!inp||!inp.value.trim()){toast('সঠিক দাম লিখুন!');return;}
  const r=await fetch('/api/suggest_price.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({station_id:sid,fuel_type:fuel,price:inp.value.trim()})});
  const d=await r.json();
  if(d.success){toast(fuel+' সাজেশন জমা হয়েছে!');openDP(sid);}else toast(d.error||'সমস্যা।');
}

// Report Modal
function openRM(sid){
  rmSid=sid||null;
  document.getElementById('rms').value='';
  document.getElementById('rm-res').style.display='none';
  document.getElementById('rm-sel').style.display='none';
  document.getElementById('rm-nt').value='';
  if(sid){const s=allSt.find(x=>x.id==sid);if(s){document.getElementById('rm-sel').textContent='📍 '+s.name;document.getElementById('rm-sel').style.display='block';}}
  document.getElementById('rm').classList.add('open');
}
function closeRM(){document.getElementById('rm').classList.remove('open');}
function selO(el,gid){document.querySelectorAll('#'+gid+' .oo').forEach(o=>o.classList.remove('on'));el.classList.add('on');}
function getO(gid){return document.querySelector('#'+gid+' .oo.on')?.dataset.v||'';}
function rmSearch(){
  const q=document.getElementById('rms').value.toLowerCase();
  const res=document.getElementById('rm-res');
  if(!q){res.style.display='none';return;}
  const m=allSt.filter(s=>s.name.toLowerCase().includes(q)).slice(0,7);
  if(!m.length){res.style.display='none';return;}
  res.style.display='block';
  res.innerHTML=m.map(s=>`<div class="sres-it" onclick="selSt(${s.id},'${esc(s.name)}')" ><h4>${esc(s.name)}</h4><p>${esc(s.address||'')}</p></div>`).join('');
}
function selSt(id,name){
  rmSid=id;
  document.getElementById('rm-res').style.display='none';
  document.getElementById('rm-sel').textContent='📍 '+name;
  document.getElementById('rm-sel').style.display='block';
  document.getElementById('rms').value='';
}
async function submitRep(){
  if(!rmSid){toast('স্টেশন বেছে নিন!');return;}
  const b={station_id:rmSid,status:getO('og-st'),serial_status:getO('og-ser'),note:document.getElementById('rm-nt').value.trim()};
  const r=await fetch('/api/report.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
  const d=await r.json();
  if(d.success){
    toast('রিপোর্ট জমা হয়েছে! ধন্যবাদ। ✅');
    closeRM();
    if(markers[rmSid]){markers[rmSid].setIcon(mkIcon(b.status));}
    loadRep();
  }else toast(d.error||'সমস্যা।');
}

// Bottom sheet
function toggleBS(){const bs=document.getElementById('bs');bs.classList.contains('col')?bs.classList.replace('col','exp'):bs.classList.replace('exp','col');}
let bsY=0;
document.getElementById('bs').addEventListener('touchstart',e=>{bsY=e.touches[0].clientY;},{passive:true});
document.getElementById('bs').addEventListener('touchend',e=>{
  const dy=e.changedTouches[0].clientY-bsY;
  const bs=document.getElementById('bs');
  if(dy>50)bs.classList.replace('exp','col');
  else if(dy<-50)bs.classList.replace('col','exp');
},{passive:true});

function toast(msg){clearTimeout(toastT);const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');toastT=setTimeout(()=>t.classList.remove('show'),3500);}
window.addEventListener('resize',()=>map&&map.invalidateSize());

(async()=>{initMap();await loadSt();await loadRep();setInterval(loadRep,60000);})();
</script>
</body>
</html>
